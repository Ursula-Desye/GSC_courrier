
from pathlib import Path
from django import forms
from django.core.paginator import Paginator
from django.contrib.auth.decorators import login_required
from django.contrib import messages
from django.core.exceptions import PermissionDenied
from django.db import transaction
from django.db.models import Q
from django.shortcuts import render, redirect, get_object_or_404
from django.utils import timezone

from .models import (
    Courrier,
    Affectation,
    Historique,
    Service,
    PieceJointe,
    RetourCourrier,
)

from .forms import CourrierForm, AffectationForm

from .permissions import (
    obtenir_profil,
    utilisateur_peut_consulter,
    utilisateur_peut_enregistrer,
    utilisateur_peut_modifier_courrier,
    utilisateur_peut_transmettre,
    utilisateur_peut_affecter_agent,
    utilisateur_peut_traiter_courrier,
    utilisateur_peut_cloturer_courrier,
    utilisateur_peut_retourner_courrier,
    utilisateur_peut_reouvrir_courrier,
)


# =====================================================
# FORMULAIRES DES ACTIONS
# =====================================================

class TraitementForm(forms.Form):

    statut = forms.ChoiceField(
        choices=[
            ("EN_COURS", "En cours de traitement"),
            ("EN_ATTENTE", "En attente"),
            ("TRAITE", "Traité"),
        ],
        label="État du traitement"
    )

    observation = forms.CharField(
        required=False,
        widget=forms.Textarea(attrs={"rows": 4}),
        label="Observation"
    )


class RetourForm(forms.Form):

    motif = forms.CharField(
        required=True,
        widget=forms.Textarea(attrs={"rows": 4}),
        label="Motif du retour"
    )


class MotifForm(forms.Form):

    motif = forms.CharField(
        required=True,
        widget=forms.Textarea(attrs={"rows": 4}),
        label="Motif"
    )


class PieceJointeForm(forms.Form):

    fichier = forms.FileField(
        label="Fichier à joindre"
    )

    def clean_fichier(self):

        fichier = self.cleaned_data["fichier"]

        extensions = [
            ".pdf", ".doc", ".docx",
            ".xls", ".xlsx",
            ".jpg", ".jpeg", ".png"
        ]

        extension = Path(fichier.name).suffix.lower()

        if extension not in extensions:
            raise forms.ValidationError(
                "Format non autorisé. Formats acceptés : PDF, DOC, DOCX, XLS, XLSX, JPG, JPEG et PNG."
            )

        if fichier.size > 20 * 1024 * 1024:
            raise forms.ValidationError(
                "Le fichier ne doit pas dépasser 20 Mo."
            )

        return fichier


# =====================================================
# SERVICES DIRIGÉS PAR UN RESPONSABLE
# =====================================================

def services_du_responsable(user):

    return Service.objects.filter(
        responsable=user,
        actif=True
    )


def identifiants_services_responsable(user):

    return services_du_responsable(user).values_list(
        "id",
        flat=True
    )


# =====================================================
# CONTROLE DES DROITS
# =====================================================

def verifier_droit_consultation(user):

    if not utilisateur_peut_consulter(user):
        raise PermissionDenied(
            "Vous ne disposez pas du droit de consultation."
        )

    return obtenir_profil(user)


def verifier_droit_modification(user):

    profil = obtenir_profil(user)

    if profil == "ADMIN":
        return profil

    if not utilisateur_peut_modifier_courrier(user, None):
        raise PermissionDenied(
            "Vous ne disposez pas du droit de modification."
        )

    return profil


# =====================================================
# FILTRAGE DES COURRIERS SELON LE PROFIL
# =====================================================

def courriers_accessibles(user):

    profil = verifier_droit_consultation(user)

    qs = Courrier.objects.select_related(
        "service",
        "responsable",
        "cree_par"
    ).distinct()

    if profil in ["ADMIN", "DIRECTION"]:
        return qs

    confidentialite_normale = (
        Q(confidentialite=Courrier.Confidentialite.NORMALE)
        & ~Q(priorite=Courrier.Priorite.CONFIDENTIELLE)
    )

    confidentialite_restraint = (
        Q(confidentialite__in=[
            Courrier.Confidentialite.CONFIDENTIELLE,
            Courrier.Confidentialite.STRICTE,
        ])
        | Q(priorite=Courrier.Priorite.CONFIDENTIELLE)
    )

    if profil in ["ACCUEIL", "SECRETARIAT"]:

        courriers_normaux = qs.filter(
            confidentialite_normale
        )

        courriers_confidentiels_non_transmis = qs.filter(
            confidentialite_restraint,
            statut="ENREGISTRE"
        ).exclude(
            affectations__active=True
        )

        return (
            courriers_normaux
            | courriers_confidentiels_non_transmis
        ).distinct()

    if profil == "RESPONSABLE":

        return qs.filter(
            service__responsable=user
        ).distinct()

    if profil == "AGENT":

        return qs.filter(
            affectations__agent=user,
            affectations__active=True
        ).filter(
            confidentialite_normale
        ).distinct()

    return qs.none()


def obtenir_courrier_accessible(user, pk):

    return get_object_or_404(
        courriers_accessibles(user),
        pk=pk
    )


# =====================================================
# HISTORIQUE
# =====================================================

def enregistrer_historique(
    courrier,
    utilisateur,
    action,
    details="",
    motif="",
    avant="",
    apres=""
):

    Historique.objects.create(
        courrier=courrier,
        utilisateur=utilisateur,
        action=action,
        details=details,
        motif=motif,
        avant=avant,
        apres=apres
    )


# =====================================================
# TABLEAU DE BORD
# =====================================================

@login_required
def dashboard(request):

    qs = courriers_accessibles(request.user)

    context = {
        "total": qs.count(),

        "entrants": qs.filter(
            sens="ENTRANT"
        ).count(),

        "sortants": qs.filter(
            sens="SORTANT"
        ).count(),

        "en_cours": qs.filter(
            statut__in=[
                "TRANSMIS",
                "EN_COURS",
                "EN_ATTENTE"
            ]
        ).count(),

        "traites": qs.filter(
            statut__in=[
                "TRAITE",
                "CLOTURE"
            ]
        ).count(),

        "recents": qs.order_by(
            "-cree_le"
        )[:8],

        "en_retard": qs.filter(
            date_limite__lt=timezone.localdate()
        ).exclude(
            statut__in=[
                "TRAITE",
                "CLOTURE"
            ]
        ).count(),

        "profil": obtenir_profil(request.user),
    }

    return render(
        request,
        "courrier/dashboard.html",
        context
    )


# =====================================================
# LISTE DES COURRIERS
# =====================================================

@login_required
def liste_courriers(request):

    qs = courriers_accessibles(request.user)

    q = request.GET.get("q", "").strip()
    sens = request.GET.get("sens", "")
    statut = request.GET.get("statut", "")
    categorie = request.GET.get("categorie", "")

    if categorie == "entrants":

        qs = qs.filter(sens="ENTRANT")
        filtre_titre = "Courriers entrants"

    elif categorie == "sortants":

        qs = qs.filter(sens="SORTANT")
        filtre_titre = "Courriers sortants"

    elif categorie == "en_cours":

        qs = qs.filter(
            statut__in=[
                "TRANSMIS",
                "EN_COURS",
                "EN_ATTENTE"
            ]
        )
        filtre_titre = "Courriers en cours de traitement"

    elif categorie == "traites":

        qs = qs.filter(
            statut__in=["TRAITE", "CLOTURE"]
        )
        filtre_titre = "Courriers traités / clôturés"

    elif categorie == "en_retard":

        qs = qs.filter(
            date_limite__lt=timezone.localdate()
        ).exclude(
            statut__in=["TRAITE", "CLOTURE"]
        )
        filtre_titre = "Courriers en retard"

    else:

        filtre_titre = "Tous les courriers"

    if q:

        qs = qs.filter(
            Q(reference__icontains=q)
            | Q(objet__icontains=q)
            | Q(expediteur__icontains=q)
            | Q(destinataire__icontains=q)
        )

    if sens in ["ENTRANT", "SORTANT"]:
        qs = qs.filter(sens=sens)

    if statut:
        qs = qs.filter(statut=statut)

    nombre_par_page = request.GET.get(
        "par_page",
        "10"
    )

    if nombre_par_page not in ["10", "25", "50", "100"]:
        nombre_par_page = "10"

    paginator = Paginator(
        qs.order_by("-cree_le"),
        int(nombre_par_page)
    )

    page_obj = paginator.get_page(
        request.GET.get("page")
    )

    context = {
        "courriers": page_obj,
        "page_obj": page_obj,
        "paginator": paginator,
        "nombre_par_page": nombre_par_page,
        "q": q,
        "sens": sens,
        "statut": statut,
        "categorie": categorie,
        "filtre_titre": filtre_titre,
    }

    return render(
        request,
        "courrier/liste.html",
        context
    )


# =====================================================
# ENREGISTREMENT D'UN NOUVEAU COURRIER
# =====================================================

@login_required
def nouveau_courrier(request):

    if not utilisateur_peut_enregistrer(request.user):
        raise PermissionDenied(
            "Vous ne disposez pas du droit d'enregistrement."
        )

    if request.method == "POST":

        form = CourrierForm(
            request.POST,
            request.FILES
        )

        if form.is_valid():

            obj = form.save(commit=False)

            obj.cree_par = request.user

            if obj.sens == "ENTRANT":

                obj.service = None
                obj.responsable = None
                obj.date_expedition = None
                obj.statut = "ENREGISTRE"
                obj.date_cloture = None

            elif obj.sens == "SORTANT":

                if not obj.date_expedition:

                    form.add_error(
                        "date_expedition",
                        "La date d'expédition est obligatoire pour un courrier sortant."
                    )

                else:

                    obj.statut = "CLOTURE"
                    obj.date_cloture = obj.date_expedition
                    obj.service = None
                    obj.responsable = None

            if not form.errors:

                with transaction.atomic():

                    obj.save()
                    form.save_m2m()

                    documents = form.cleaned_data.get(
                        "documents",
                        []
                    )

                    for fichier in documents:

                        PieceJointe.objects.create(
                            courrier=obj,
                            fichier=fichier,
                            nom_original=fichier.name,
                            type_mime=getattr(
                                fichier,
                                "content_type",
                                ""
                            ) or "",
                            taille=fichier.size,
                            ajoute_par=request.user
                        )

                    enregistrer_historique(
                        obj,
                        request.user,
                        "ENREGISTREMENT",
                        details="Création du courrier.",
                        apres=(
                            f"Référence : {obj.reference}\n"
                            f"Sens : {obj.get_sens_display()}\n"
                            f"Objet : {obj.objet}"
                        )
                    )

                messages.success(
                    request,
                    f"Le courrier {obj.reference} a été enregistré avec succès."
                )

                return redirect(
                    "detail_courrier",
                    pk=obj.pk
                )

    else:

        form = CourrierForm()

    return render(
        request,
        "courrier/formulaire.html",
        {
            "form": form,
            "titre": "Nouveau courrier",
            "libelle_bouton": "Enregistrer le courrier"
        }
    )


# =====================================================
# DETAIL D'UN COURRIER
# =====================================================

@login_required
def detail_courrier(request, pk):

    obj = obtenir_courrier_accessible(
        request.user,
        pk
    )

    profil = obtenir_profil(request.user)

    from .permissions import (
        utilisateur_peut_retourner_courrier,
        utilisateur_peut_reouvrir_courrier,
    )

    peut_modifier = (
        profil == "ADMIN"
        or utilisateur_peut_modifier_courrier(
            request.user,
            obj
        )
    )

    context = {
        "courrier": obj,

        "affectations": Affectation.objects.filter(
            courrier=obj
        ).select_related(
            "service",
            "agent",
            "transmis_par",
            "confirme_par"
        ).order_by("-date_transmission"),

        "pieces_jointes": PieceJointe.objects.filter(
            courrier=obj,
            active=True
        ).select_related("ajoute_par"),

        "historique": Historique.objects.filter(
            courrier=obj
        ).select_related(
            "utilisateur"
        ).order_by("-date_action"),

        "profil": profil,

        "peut_modifier": peut_modifier,

        "peut_transmettre": utilisateur_peut_transmettre(
            request.user,
            obj
        ),

        "peut_affecter_agent": utilisateur_peut_affecter_agent(
            request.user,
            obj
        ),

        "peut_traiter": utilisateur_peut_traiter_courrier(
            request.user,
            obj
        ),

        "peut_cloturer": utilisateur_peut_cloturer_courrier(
            request.user,
            obj
        ),

        "peut_retourner": utilisateur_peut_retourner_courrier(
            request.user,
            obj
        ),

        "peut_reouvrir": utilisateur_peut_reouvrir_courrier(
            request.user,
            obj
        ),

        "peut_ajouter_piece_jointe": peut_modifier or (
            profil in ["RESPONSABLE", "AGENT"]
        ),

    }

    return render(
        request,
        "courrier/detail.html",
        context
    )


# =====================================================
# MODIFICATION D'UN COURRIER
# =====================================================

@login_required
def modifier_courrier(request, pk):

    obj = obtenir_courrier_accessible(
        request.user,
        pk
    )

    profil = obtenir_profil(request.user)

    if not (
        profil == "ADMIN"
        or utilisateur_peut_modifier_courrier(
            request.user,
            obj
        )
    ):
        raise PermissionDenied(
            "Vous ne pouvez pas modifier ce courrier."
        )

    if request.method == "POST":

        form = CourrierForm(
            request.POST,
            request.FILES,
            instance=obj
        )

        if form.is_valid():

            ancien_service = obj.service
            ancienne_reference = obj.reference

            with transaction.atomic():

                modification = form.save(commit=False)

                if profil != "ADMIN":

                    modification.service = ancien_service
                    modification.responsable = obj.responsable

                modification.save()
                form.save_m2m()

                enregistrer_historique(
                    obj,
                    request.user,
                    "MODIFICATION",
                    details="Modification de la fiche courrier.",
                    avant=f"Référence : {ancienne_reference}",
                    apres=f"Objet : {obj.objet}"
                )

            messages.success(
                request,
                "Le courrier a été modifié."
            )

            return redirect(
                "detail_courrier",
                pk=obj.pk
            )

    else:

        form = CourrierForm(instance=obj)

    return render(
        request,
        "courrier/formulaire.html",
        {
            "form": form,
            "courrier": obj,
            "titre": "Modifier le courrier",
            "libelle_bouton": "Enregistrer les modifications"
        }
    )


# =====================================================
# TRANSMISSION D'UN COURRIER À UN SERVICE
# =====================================================

@login_required
def transmettre_courrier(request, pk):

    obj = obtenir_courrier_accessible(
        request.user,
        pk
    )

    if not utilisateur_peut_transmettre(
        request.user,
        obj
    ):
        raise PermissionDenied(
            "Vous ne disposez pas du droit de transmettre ce courrier."
        )

    if obj.sens != "ENTRANT" or obj.statut != "ENREGISTRE":
        raise PermissionDenied(
            "Seul un courrier entrant enregistré et non transmis peut être transmis."
        )

    if request.method == "POST":

        form = AffectationForm(request.POST)

        if form.is_valid():

            affectation = form.save(commit=False)

            if not affectation.service.actif:

                form.add_error(
                    "service",
                    "Ce service n'est plus actif."
                )

            if not form.errors:

                with transaction.atomic():

                    Affectation.objects.filter(
                        courrier=obj,
                        active=True
                    ).update(active=False)

                    affectation.courrier = obj
                    affectation.transmis_par = request.user
                    affectation.active = True
                    affectation.save()

                    obj.service = affectation.service
                    obj.responsable = affectation.service.responsable
                    obj.statut = "TRANSMIS"
                    obj.save(
                        update_fields=[
                            "service",
                            "responsable",
                            "statut",
                            "modifie_le"
                        ]
                    )

                    enregistrer_historique(
                        obj,
                        request.user,
                        "TRANSMISSION",
                        details=(
                            f"Courrier transmis au service "
                            f"{affectation.service.nom}."
                        )
                    )

                messages.success(
                    request,
                    "Le courrier a été transmis au service sélectionné."
                )

                return redirect(
                    "detail_courrier",
                    pk=obj.pk
                )

    else:

        form = AffectationForm()

    return render(
        request,
        "courrier/formulaire.html",
        {
            "form": form,
            "courrier": obj,
            "titre": "Transmettre le courrier",
            "libelle_bouton": "Confirmer la transmission"
        }
    )


# =====================================================
# AFFECTATION À UN AGENT
# =====================================================

@login_required
def affecter_agent(request, pk):

    obj = obtenir_courrier_accessible(
        request.user,
        pk
    )

    if not utilisateur_peut_affecter_agent(
        request.user,
        obj
    ):
        raise PermissionDenied(
            "Vous ne pouvez pas affecter ce courrier à un agent."
        )

    if not obj.service_id:
        raise PermissionDenied(
            "Ce courrier n'est rattaché à aucun service."
        )

    if request.method == "POST":

        form = AffectationForm(
            request.POST
        )

        if form.is_valid():

            nouvelle = form.save(commit=False)

            if nouvelle.service_id != obj.service_id:

                form.add_error(
                    "service",
                    "L'affectation doit rester dans le service destinataire."
                )

            if not nouvelle.agent:

                form.add_error(
                    "agent",
                    "Veuillez sélectionner un agent."
                )

            if not form.errors:

                with transaction.atomic():

                    Affectation.objects.filter(
                        courrier=obj,
                        active=True
                    ).update(active=False)

                    nouvelle.courrier = obj
                    nouvelle.transmis_par = request.user
                    nouvelle.active = True
                    nouvelle.save()

                    enregistrer_historique(
                        obj,
                        request.user,
                        "AFFECTATION_AGENT",
                        details=(
                            f"Courrier affecté à "
                            f"{nouvelle.agent.get_full_name() or nouvelle.agent.username}."
                        )
                    )

                messages.success(
                    request,
                    "Le courrier a été affecté à l'agent."
                )

                return redirect(
                    "detail_courrier",
                    pk=obj.pk
                )

    else:

        form = AffectationForm(
            initial={
                "service": obj.service_id
            }
        )

    return render(
        request,
        "courrier/formulaire.html",
        {
            "form": form,
            "courrier": obj,
            "titre": "Affecter à un agent",
            "libelle_bouton": "Confirmer l'affectation"
        }
    )


# =====================================================
# TRAITEMENT D'UN COURRIER
# =====================================================

@login_required
def traiter_courrier(request, pk):

    obj = obtenir_courrier_accessible(
        request.user,
        pk
    )

    if not utilisateur_peut_traiter_courrier(
        request.user,
        obj
    ):
        raise PermissionDenied(
            "Vous ne pouvez pas traiter ce courrier."
        )

    affectation = Affectation.objects.filter(
        courrier=obj,
        active=True
    ).order_by("-date_transmission").first()

    if request.method == "POST":

        form = TraitementForm(request.POST)

        if form.is_valid():

            nouveau_statut = form.cleaned_data["statut"]
            observation = form.cleaned_data["observation"]

            with transaction.atomic():

                if affectation:

                    affectation.statut = nouveau_statut
                    affectation.observation = observation
                    affectation.save(
                        update_fields=[
                            "statut",
                            "observation"
                        ]
                    )

                obj.statut = nouveau_statut
                obj.save(
                    update_fields=[
                        "statut",
                        "modifie_le"
                    ]
                )

                enregistrer_historique(
                    obj,
                    request.user,
                    "TRAITEMENT",
                    details=f"Statut : {nouveau_statut}",
                    motif=observation
                )

            messages.success(
                request,
                "Le traitement du courrier a été enregistré."
            )

            return redirect(
                "detail_courrier",
                pk=obj.pk
            )

    else:

        form = TraitementForm(
            initial={
                "statut": obj.statut
                if obj.statut in [
                    "EN_COURS",
                    "EN_ATTENTE",
                    "TRAITE"
                ]
                else "EN_COURS"
            }
        )

    return render(
        request,
        "courrier/formulaire.html",
        {
            "form": form,
            "courrier": obj,
            "titre": "Traitement du courrier",
            "libelle_bouton": "Enregistrer le traitement"
        }
    )


# =====================================================
# RETOUR D'UN COURRIER AU SECRÉTARIAT
# =====================================================

@login_required
def retourner_courrier(request, pk):

    obj = obtenir_courrier_accessible(
        request.user,
        pk
    )

    if not utilisateur_peut_retourner_courrier(
        request.user,
        obj
    ):
        raise PermissionDenied(
            "Vous ne pouvez pas retourner ce courrier."
        )

    if request.method == "POST":

        form = RetourForm(request.POST)

        if form.is_valid():

            motif = form.cleaned_data["motif"]

            with transaction.atomic():

                RetourCourrier.objects.create(
                    courrier=obj,
                    retourne_par=request.user,
                    motif=motif
                )

                Affectation.objects.filter(
                    courrier=obj,
                    active=True
                ).update(active=False)

                obj.service = None
                obj.responsable = None
                obj.statut = "ENREGISTRE"
                obj.save(
                    update_fields=[
                        "service",
                        "responsable",
                        "statut",
                        "modifie_le"
                    ]
                )

                enregistrer_historique(
                    obj,
                    request.user,
                    "RETOUR_SECRÉTARIAT",
                    details="Courrier retourné au Secrétariat.",
                    motif=motif
                )

            messages.success(
                request,
                "Le courrier a été retourné au Secrétariat."
            )

            return redirect(
                "detail_courrier",
                pk=obj.pk
            )

    else:

        form = RetourForm()

    return render(
        request,
        "courrier/formulaire.html",
        {
            "form": form,
            "courrier": obj,
            "titre": "Retourner le courrier",
            "libelle_bouton": "Confirmer le retour"
        }
    )


# =====================================================
# CLÔTURE D'UN COURRIER
# =====================================================

@login_required
def cloturer_courrier(request, pk):

    obj = obtenir_courrier_accessible(
        request.user,
        pk
    )

    if not utilisateur_peut_cloturer_courrier(
        request.user,
        obj
    ):
        raise PermissionDenied(
            "Vous ne disposez pas du droit de clôturer ce courrier."
        )

    if obj.sens != "ENTRANT":
        raise PermissionDenied(
            "La clôture manuelle concerne uniquement les courriers entrants."
        )

    if obj.statut != "TRAITE":

        messages.warning(
            request,
            "Le courrier doit être marqué comme traité avant sa clôture."
        )

        return redirect(
            "detail_courrier",
            pk=obj.pk
        )

    if request.method == "POST":

        with transaction.atomic():

            obj.statut = "CLOTURE"
            obj.date_cloture = timezone.localdate()
            obj.save(
                update_fields=[
                    "statut",
                    "date_cloture",
                    "modifie_le"
                ]
            )

            enregistrer_historique(
                obj,
                request.user,
                "CLOTURE",
                details="Clôture du courrier."
            )

        messages.success(
            request,
            f"Le courrier {obj.reference} a été clôturé."
        )

        return redirect(
            "detail_courrier",
            pk=obj.pk
        )

    return render(
        request,
        "courrier/confirmation_cloture.html",
        {
            "courrier": obj,
            "titre": "Clôturer le courrier"
        }
    )


# =====================================================
# RÉOUVERTURE D'UN COURRIER
# =====================================================

@login_required
def reouvrir_courrier(request, pk):

    obj = obtenir_courrier_accessible(
        request.user,
        pk
    )

    if not utilisateur_peut_reouvrir_courrier(
        request.user,
        obj
    ):
        raise PermissionDenied(
            "Vous ne pouvez pas rouvrir ce courrier."
        )

    if obj.statut != "CLOTURE":
        messages.warning(
            request,
            "Ce courrier n'est pas clôturé."
        )
        return redirect(
            "detail_courrier",
            pk=obj.pk
        )

    if request.method == "POST":

        form = MotifForm(request.POST)

        if form.is_valid():

            motif = form.cleaned_data["motif"]

            with transaction.atomic():

                obj.statut = (
                    "TRANSMIS"
                    if obj.service_id
                    else "ENREGISTRE"
                )

                obj.date_cloture = None

                obj.save(
                    update_fields=[
                        "statut",
                        "date_cloture",
                        "modifie_le"
                    ]
                )

                enregistrer_historique(
                    obj,
                    request.user,
                    "REOUVERTURE",
                    details="Réouverture du courrier.",
                    motif=motif
                )

            messages.success(
                request,
                "Le courrier a été rouvert."
            )

            return redirect(
                "detail_courrier",
                pk=obj.pk
            )

    else:

        form = MotifForm()

    return render(
        request,
        "courrier/formulaire.html",
        {
            "form": form,
            "courrier": obj,
            "titre": "Réouvrir le courrier",
            "libelle_bouton": "Confirmer la réouverture"
        }
    )


# =====================================================
# AJOUT D'UNE PIÈCE JOINTE
# =====================================================

@login_required
def ajouter_piece_jointe(request, pk):

    obj = obtenir_courrier_accessible(
        request.user,
        pk
    )

    profil = obtenir_profil(request.user)

    autorise = (
        profil == "ADMIN"
        or utilisateur_peut_modifier_courrier(
            request.user,
            obj
        )
        or (
            profil in ["RESPONSABLE", "AGENT"]
            and utilisateur_peut_traiter_courrier(
                request.user,
                obj
            )
        )
    )

    if not autorise:
        raise PermissionDenied(
            "Vous ne pouvez pas ajouter de pièce jointe à ce courrier."
        )

    if request.method == "POST":

        form = PieceJointeForm(request.POST, request.FILES)

        if form.is_valid():

            fichier = form.cleaned_data["fichier"]

            with transaction.atomic():

                PieceJointe.objects.create(
                    courrier=obj,
                    fichier=fichier,
                    nom_original=fichier.name,
                    type_mime=getattr(
                        fichier,
                        "content_type",
                        ""
                    ) or "",
                    taille=fichier.size,
                    ajoute_par=request.user
                )

                enregistrer_historique(
                    obj,
                    request.user,
                    "AJOUT_PIECE_JOINTE",
                    details=f"Ajout du fichier : {fichier.name}"
                )

            messages.success(
                request,
                "La pièce jointe a été ajoutée."
            )

            return redirect(
                "detail_courrier",
                pk=obj.pk
            )

    else:

        form = PieceJointeForm()

    return render(
        request,
        "courrier/formulaire.html",
        {
            "form": form,
            "courrier": obj,
            "titre": "Ajouter une pièce jointe",
            "libelle_bouton": "Ajouter le fichier"
        }
    )


# =====================================================
# RETRAIT LOGIQUE D'UNE PIÈCE JOINTE
# =====================================================

@login_required
def retirer_piece_jointe(request, pk, piece_id):

    obj = obtenir_courrier_accessible(
        request.user,
        pk
    )

    piece = get_object_or_404(
        PieceJointe,
        pk=piece_id,
        courrier=obj,
        active=True
    )

    profil = obtenir_profil(request.user)

    autorise = (
        profil == "ADMIN"
        or utilisateur_peut_modifier_courrier(
            request.user,
            obj
        )
    )

    if not autorise:
        raise PermissionDenied(
            "Vous ne pouvez pas retirer cette pièce jointe."
        )

    if request.method != "POST":
        raise PermissionDenied(
            "Cette opération doit être effectuée par formulaire."
        )

    with transaction.atomic():

        piece.active = False
        piece.retire_par = request.user
        piece.retire_le = timezone.now()
        piece.motif_retrait = request.POST.get(
            "motif",
            "Retrait de la pièce jointe."
        )
        piece.save(
            update_fields=[
                "active",
                "retire_par",
                "retire_le",
                "motif_retrait"
            ]
        )

        enregistrer_historique(
            obj,
            request.user,
            "RETRAIT_PIECE_JOINTE",
            details=f"Retrait logique du fichier : {piece.nom_original}",
            motif=piece.motif_retrait
        )

    messages.success(
        request,
        "La pièce jointe a été retirée de la fiche. Le fichier n'a pas été supprimé physiquement."
    )

    return redirect(
        "detail_courrier",
        pk=obj.pk
    )


from pathlib import Path

from django import forms
from django.core.paginator import Paginator
from django.contrib.auth.decorators import login_required
from django.core.exceptions import PermissionDenied
from django.db import transaction
from django.db.models import Q
from django.shortcuts import render, redirect, get_object_or_404
from django.utils import timezone
from django.contrib import messages

from .models import (
    Courrier,
    Affectation,
    Historique,
    Service,
    PieceJointe,
    RetourCourrier,
    AutorisationConfidentialite,
    JournalAccesConfidentiel,
    ResponsableService,
)

from .forms import CourrierForm, AffectationForm

from .permissions import (
    obtenir_profil,
    utilisateur_peut_consulter,
    utilisateur_peut_consulter_courrier,
    utilisateur_peut_consulter_contenu_courrier,
    utilisateur_peut_consulter_piece_confidentielle,
    utilisateur_peut_consulter_historique_confidentiel,
    utilisateur_peut_enregistrer,
    utilisateur_peut_modifier_courrier,
    utilisateur_peut_transmettre,
    utilisateur_peut_affecter_agent,
    utilisateur_peut_traiter_courrier,
    utilisateur_peut_cloturer_courrier,
    utilisateur_peut_retourner_courrier,
    utilisateur_peut_reouvrir_courrier,
    utilisateur_est_responsable_du_service,
    utilisateur_est_responsable_du_courrier,
    services_accessibles_du_responsable,
    responsable_peut_gerer_categorie,
    agent_est_affecte_au_courrier,
    courrier_est_confidentiel,
    courrier_est_strictement_confidentiel,
    autorisation_confidentielle_valide,
    utilisateur_est_destinataire_confidentiel,
)


# ============================================================
# FORMULAIRES DES ACTIONS
# ============================================================

class TraitementForm(forms.Form):

    statut = forms.ChoiceField(
        choices=[
            ("EN_COURS", "En cours de traitement"),
            ("EN_ATTENTE", "En attente"),
            ("TRAITE", "Traité"),
        ],
        label="État du traitement",
        widget=forms.Select(attrs={"class": "form-select"}),
    )

    observation = forms.CharField(
        required=False,
        label="Observation",
        widget=forms.Textarea(attrs={
            "class": "form-control",
            "rows": 4,
        }),
    )


class RetourForm(forms.Form):

    motif = forms.CharField(
        required=True,
        label="Motif du retour",
        widget=forms.Textarea(attrs={
            "class": "form-control",
            "rows": 4,
        }),
    )


class MotifForm(forms.Form):

    motif = forms.CharField(
        required=True,
        label="Motif",
        widget=forms.Textarea(attrs={
            "class": "form-control",
            "rows": 4,
        }),
    )


class PieceJointeForm(forms.Form):

    fichier = forms.FileField(
        label="Fichier à joindre",
        widget=forms.ClearableFileInput(attrs={
            "class": "form-control",
        }),
    )

    def clean_fichier(self):

        fichier = self.cleaned_data["fichier"]

        extensions = {
            ".pdf", ".doc", ".docx",
            ".xls", ".xlsx",
            ".jpg", ".jpeg", ".png",
        }

        extension = Path(fichier.name).suffix.lower()

        if extension not in extensions:
            raise forms.ValidationError(
                "Format non autorisé. Formats acceptés : "
                "PDF, DOC, DOCX, XLS, XLSX, JPG, JPEG et PNG."
            )

        if not fichier.size:
            raise forms.ValidationError(
                "Le fichier est vide."
            )

        if fichier.size > 20 * 1024 * 1024:
            raise forms.ValidationError(
                "Le fichier ne doit pas dépasser 20 Mo."
            )

        return fichier


# ============================================================
# OUTILS DE CONFIDENTIALITÉ
# ============================================================

def journaliser_acces_confidentiel(
    courrier,
    utilisateur,
    action,
    motif="",
):
    """
    Enregistre les consultations sensibles.
    """

    if not courrier or not utilisateur:
        return

    if not courrier_est_confidentiel(courrier):
        return

    JournalAccesConfidentiel.objects.create(
        courrier=courrier,
        utilisateur=utilisateur,
        action=action,
        motif=motif,
    )


def utilisateur_a_acces_confidentiel(user, courrier, type_acces="CONTENU"):
    """
    Vérifie les autorisations explicites et le destinataire désigné.
    L'administrateur technique ne reçoit aucun accès automatique.
    """

    if not user or not courrier:
        return False

    if utilisateur_est_destinataire_confidentiel(user, courrier):
        return True

    return autorisation_confidentielle_valide(
        user,
        courrier,
        type_acces,
    )


def utilisateur_peut_voir_metadonnees(user, courrier):
    """
    Les métadonnées et le contenu sont deux niveaux d'accès distincts.
    """

    if utilisateur_peut_consulter_courrier(user, courrier):
        return True

    # Une désignation ou une autorisation explicite permet
    # de retrouver le courrier pour lequel elle a été accordée.
    if utilisateur_a_acces_confidentiel(
        user,
        courrier,
        "CONTENU",
    ):
        return True

    if utilisateur_a_acces_confidentiel(
        user,
        courrier,
        "PIECES_JOINTES",
    ):
        return True

    if utilisateur_a_acces_confidentiel(
        user,
        courrier,
        "HISTORIQUE",
    ):
        return True

    return False


def utilisateur_peut_voir_contenu(user, courrier):

    if not courrier_est_confidentiel(courrier):
        return utilisateur_peut_consulter_contenu_courrier(
            user,
            courrier,
        )

    autorise = (
        utilisateur_est_destinataire_confidentiel(user, courrier)
        or autorisation_confidentielle_valide(
            user,
            courrier,
            "CONTENU",
        )
    )

    return bool(autorise)


def utilisateur_peut_voir_pieces(user, courrier):

    if not courrier_est_confidentiel(courrier):
        return utilisateur_peut_consulter_piece_confidentielle(
            user,
            courrier,
        )

    autorise = (
        utilisateur_est_destinataire_confidentiel(user, courrier)
        or autorisation_confidentielle_valide(
            user,
            courrier,
            "PIECES_JOINTES",
        )
    )

    return bool(autorise)


def utilisateur_peut_voir_historique(user, courrier):

    if not courrier_est_confidentiel(courrier):
        return utilisateur_peut_consulter_historique_confidentiel(
            user,
            courrier,
        )

    autorise = (
        utilisateur_est_destinataire_confidentiel(user, courrier)
        or autorisation_confidentielle_valide(
            user,
            courrier,
            "HISTORIQUE",
        )
    )

    return bool(autorise)


# ============================================================
# DROITS DE CONSULTATION
# ============================================================

def verifier_droit_consultation(user):

    if not utilisateur_peut_consulter(user):
        raise PermissionDenied(
            "Vous ne disposez pas du droit de consultation."
        )

    return obtenir_profil(user)


def verifier_droit_modification(user, courrier=None):

    profil = obtenir_profil(user)

    if profil == "ADMIN":
        if courrier and courrier_est_confidentiel(courrier):
            raise PermissionDenied(
                "L'administrateur technique ne peut pas modifier "
                "le contenu d'un courrier confidentiel."
            )
        return profil

    if not utilisateur_peut_modifier_courrier(user, courrier):
        raise PermissionDenied(
            "Vous ne disposez pas du droit de modification."
        )

    return profil


# ============================================================
# FILTRAGE DES COURRIERS
# ============================================================

def courriers_accessibles(user):

    profil = verifier_droit_consultation(user)

    qs = Courrier.objects.select_related(
        "service",
        "responsable",
        "cree_par",
        "categorie",
        "destinataire_confidentiel",
    ).distinct()

    # L'administrateur technique ne voit que les courriers ordinaires.
    if profil == "ADMIN":
        return qs.filter(
            confidentialite=Courrier.Confidentialite.NORMALE
        ).exclude(
            priorite=Courrier.Priorite.CONFIDENTIELLE
        )

    # Accueil et Secrétariat peuvent voir les métadonnées nécessaires
    # à l'enregistrement et à l'orientation.
    if profil in ["ACCUEIL", "SECRETARIAT"]:
        return qs

    # Direction : uniquement les structures dont elle est responsable.
    if profil == "DIRECTION":

        services_ids = ResponsableService.objects.filter(
            utilisateur=user,
            actif=True,
            service__actif=True,
        ).values_list("service_id", flat=True)

        services_anciens = Service.objects.filter(
            responsable=user,
            actif=True,
        ).values_list("id", flat=True)

        ids = set(services_ids) | set(services_anciens)

        return qs.filter(
            service_id__in=ids
        )

    # Responsable : périmètre configuré, catégories et enfants éventuels.
    if profil == "RESPONSABLE":

        services = services_accessibles_du_responsable(user)

        ids_courriers = qs.filter(
            service__in=services
        ).values_list("id", flat=True)

        ids_valides = []

        for courrier in qs.filter(pk__in=ids_courriers):
            if responsable_peut_gerer_categorie(user, courrier):
                ids_valides.append(courrier.pk)

        return qs.filter(
            pk__in=ids_valides
        )

    # Agent : affectations individuelles actives.
    if profil == "AGENT":

        return qs.filter(
            affectations__agent=user,
            affectations__active=True,
            affectations__type_affectation="AGENT",
        ).distinct()

    return qs.none()


def obtenir_courrier_accessible(user, pk):

    courrier = get_object_or_404(
        Courrier.objects.select_related(
            "service",
            "responsable",
            "categorie",
            "destinataire_confidentiel",
            "cree_par",
        ),
        pk=pk,
    )

    if not utilisateur_peut_voir_metadonnees(user, courrier):
        raise PermissionDenied(
            "Vous ne disposez pas du droit de consulter ce courrier."
        )

    return courrier


# ============================================================
# HISTORIQUE
# ============================================================

def enregistrer_historique(
    courrier,
    utilisateur,
    action,
    details="",
    motif="",
    avant="",
    apres="",
):

    Historique.objects.create(
        courrier=courrier,
        utilisateur=utilisateur,
        action=action,
        details=details,
        motif=motif,
        avant=avant,
        apres=apres,
    )


# ============================================================
# ENREGISTREMENT DES PIÈCES JOINTES
# ============================================================

def enregistrer_pieces_jointes(courrier, fichiers, utilisateur):
    """
    Enregistre les fichiers et conserve les versions précédentes.
    """

    for fichier in fichiers:

        precedente = (
            PieceJointe.objects
            .select_for_update()
            .filter(
                courrier=courrier,
                nom_original__iexact=fichier.name,
            )
            .order_by("-version", "-pk")
            .first()
        )

        nouvelle_version = (
            precedente.version + 1
            if precedente
            else 1
        )

        if precedente and precedente.active:

            precedente.active = False
            precedente.retire_par = utilisateur
            precedente.retire_le = timezone.now()
            precedente.motif_retrait = (
                "Remplacé par une nouvelle version du fichier."
            )

            precedente.save(
                update_fields=[
                    "active",
                    "retire_par",
                    "retire_le",
                    "motif_retrait",
                ]
            )

        PieceJointe.objects.create(
            courrier=courrier,
            fichier=fichier,
            nom_original=fichier.name,
            type_mime=getattr(fichier, "content_type", "") or "",
            taille=fichier.size,
            version=nouvelle_version,
            version_precedente=precedente,
            ajoute_par=utilisateur,
        )


# ============================================================
# TABLEAU DE BORD
# ============================================================

@login_required
def dashboard(request):

    qs = courriers_accessibles(request.user)

    context = {
        "total": qs.count(),

        "entrants": qs.filter(
            sens=Courrier.Sens.ENTRANT
        ).count(),

        "sortants": qs.filter(
            sens=Courrier.Sens.SORTANT
        ).count(),

        "en_cours": qs.filter(
            statut__in=[
                Courrier.Statut.TRANSMIS,
                Courrier.Statut.EN_COURS,
                Courrier.Statut.EN_ATTENTE,
            ]
        ).count(),

        "traites": qs.filter(
            statut__in=[
                Courrier.Statut.TRAITE,
                Courrier.Statut.CLOTURE,
            ]
        ).count(),

        "recents": qs.order_by("-cree_le")[:8],

        "en_retard": qs.filter(
            date_limite__lt=timezone.localdate()
        ).exclude(
            statut__in=[
                Courrier.Statut.TRAITE,
                Courrier.Statut.CLOTURE,
            ]
        ).count(),

        "profil": obtenir_profil(request.user),
    }

    return render(
        request,
        "courrier/dashboard.html",
        context,
    )


# ============================================================
# LISTE DES COURRIERS
# ============================================================

@login_required
def liste_courriers(request):

    qs = courriers_accessibles(request.user)

    q = request.GET.get("q", "").strip()
    sens = request.GET.get("sens", "")
    statut = request.GET.get("statut", "")
    categorie = request.GET.get("categorie", "")
    retard = request.GET.get("retard", "")

    if retard == "1":

        qs = qs.filter(
            date_limite__lt=timezone.localdate()
        ).exclude(
            statut__in=["TRAITE", "CLOTURE"]
        )

        filtre_titre = "Courriers en retard"

    elif categorie == "entrants":

        qs = qs.filter(sens="ENTRANT")
        filtre_titre = "Courriers entrants"

    elif categorie == "sortants":

        qs = qs.filter(sens="SORTANT")
        filtre_titre = "Courriers sortants"

    elif categorie == "en_cours":

        qs = qs.filter(
            statut__in=[
                "TRANSMIS",
                "EN_COURS",
                "EN_ATTENTE",
            ]
        )

        filtre_titre = "Courriers en cours de traitement"

    elif categorie == "traites":

        qs = qs.filter(
            statut__in=["TRAITE", "CLOTURE"]
        )

        filtre_titre = "Courriers traités / clôturés"

    elif categorie == "en_retard":

        qs = qs.filter(
            date_limite__lt=timezone.localdate()
        ).exclude(
            statut__in=["TRAITE", "CLOTURE"]
        )

        filtre_titre = "Courriers en retard"

    else:
        filtre_titre = "Tous les courriers"

    if q:

        profil = obtenir_profil(request.user)

        # Pour les courriers confidentiels, ne pas rechercher
        # dans les descriptions ou les informations de contenu.
        if profil in ["ACCUEIL", "SECRETARIAT"]:

            normaux = qs.filter(
                Q(confidentialite=Courrier.Confidentialite.NORMALE)
                & ~Q(priorite=Courrier.Priorite.CONFIDENTIELLE)
            )

            confidentiels = qs.filter(
                Q(confidentialite__in=[
                    Courrier.Confidentialite.CONFIDENTIELLE,
                    Courrier.Confidentialite.STRICTE,
                ])
                | Q(priorite=Courrier.Priorite.CONFIDENTIELLE)
            ).filter(
                reference__icontains=q
            )

            normaux = normaux.filter(
                Q(reference__icontains=q)
                | Q(objet__icontains=q)
                | Q(expediteur__icontains=q)
                | Q(destinataire__icontains=q)
            )

            qs = normaux | confidentiels

        else:

            qs = qs.filter(
                Q(reference__icontains=q)
                | Q(objet__icontains=q)
                | Q(expediteur__icontains=q)
                | Q(destinataire__icontains=q)
            )

    if sens in ["ENTRANT", "SORTANT"]:
        qs = qs.filter(sens=sens)

    if statut:
        qs = qs.filter(statut=statut)

    nombre_par_page = request.GET.get("par_page", "10")

    if nombre_par_page not in ["10", "25", "50", "100"]:
        nombre_par_page = "10"

    paginator = Paginator(
        qs.distinct().order_by("-cree_le"),
        int(nombre_par_page),
    )

    page_obj = paginator.get_page(
        request.GET.get("page")
    )

    context = {
        "courriers": page_obj,
        "page_obj": page_obj,
        "paginator": paginator,
        "nombre_par_page": nombre_par_page,
        "q": q,
        "sens": sens,
        "statut": statut,
        "categorie": categorie,
        "filtre_titre": filtre_titre,
    }

    return render(
        request,
        "courrier/liste.html",
        context,
    )


# ============================================================
# ENREGISTREMENT D'UN NOUVEAU COURRIER
# ============================================================

@login_required
def nouveau_courrier(request):

    if not utilisateur_peut_enregistrer(request.user):
        raise PermissionDenied(
            "Vous ne disposez pas du droit d'enregistrement."
        )

    if request.method == "POST":

        form = CourrierForm(
            request.POST,
            request.FILES,
        )

        form.fields["retour"] = forms.IntegerField(
            required=False,
            widget=forms.HiddenInput(),
        )

        if form.is_valid():

            obj = form.save(commit=False)
            obj.cree_par = request.user

            retour_id = form.cleaned_data.get("retour")
            retour = None

            if retour_id:

                if obtenir_profil(request.user) != "SECRETARIAT":
                    raise PermissionDenied(
                        "Seul le Secrétariat peut enregistrer "
                        "un courrier retourné."
                    )

                retour = get_object_or_404(
                    RetourCourrier.objects.select_related("courrier"),
                    pk=retour_id,
                    traite=False,
                )

                obtenir_courrier_accessible(
                    request.user,
                    retour.courrier_id,
                )

                if obj.sens != Courrier.Sens.ENTRANT:
                    form.add_error(
                        None,
                        "Un courrier retourné doit être enregistré "
                        "comme courrier entrant.",
                    )

            if obj.sens == Courrier.Sens.ENTRANT:

                obj.service = None
                obj.responsable = None
                obj.date_expedition = None
                obj.statut = Courrier.Statut.ENREGISTRE
                obj.date_cloture = None

            elif obj.sens == Courrier.Sens.SORTANT:

                if not obj.date_expedition:
                    form.add_error(
                        "date_expedition",
                        "La date d'expédition est obligatoire "
                        "pour un courrier sortant.",
                    )
                else:
                    obj.statut = Courrier.Statut.CLOTURE
                    obj.date_cloture = obj.date_expedition
                    obj.service = None
                    obj.responsable = None

            if not form.errors:

                with transaction.atomic():

                    if retour_id:

                        retour = (
                            RetourCourrier.objects
                            .select_for_update()
                            .filter(
                                pk=retour_id,
                                traite=False,
                            )
                            .first()
                        )

                        if retour is None:
                            raise PermissionDenied(
                                "Ce retour a déjà été traité."
                            )

                    obj.save()
                    form.save_m2m()

                    enregistrer_pieces_jointes(
                        obj,
                        form.cleaned_data.get("documents", []),
                        request.user,
                    )

                    if retour:

                        retour.nouveau_courrier = obj
                        retour.traite = True

                        retour.save(
                            update_fields=[
                                "nouveau_courrier",
                                "traite",
                            ]
                        )

                    enregistrer_historique(
                        obj,
                        request.user,
                        "ENREGISTREMENT",
                        details=(
                            "Création du courrier à la suite d'un retour."
                            if retour
                            else "Création du courrier."
                        ),
                        apres=(
                            f"Référence : {obj.reference}\n"
                            f"Sens : {obj.get_sens_display()}\n"
                            f"Objet : {obj.objet}"
                        ),
                    )

                messages.success(
                    request,
                    f"Le courrier {obj.reference} a été enregistré.",
                )

                return redirect(
                    "detail_courrier",
                    pk=obj.pk,
                )

    else:

        form = CourrierForm()

        form.fields["retour"] = forms.IntegerField(
            required=False,
            initial=request.GET.get("retour"),
            widget=forms.HiddenInput(),
        )

    return render(
        request,
        "courrier/formulaire.html",
        {
            "form": form,
            "titre": "Nouveau courrier",
            "libelle_bouton": "Enregistrer le courrier",
        },
    )


# ============================================================
# DÉTAIL D'UN COURRIER
# ============================================================

@login_required
def detail_courrier(request, pk):

    obj = obtenir_courrier_accessible(
        request.user,
        pk,
    )

    profil = obtenir_profil(request.user)

    peut_voir_contenu = utilisateur_peut_voir_contenu(
        request.user,
        obj,
    )

    peut_voir_pieces = utilisateur_peut_voir_pieces(
        request.user,
        obj,
    )

    peut_voir_historique = utilisateur_peut_voir_historique(
        request.user,
        obj,
    )

    if courrier_est_confidentiel(obj):

        if peut_voir_contenu:
            journaliser_acces_confidentiel(
                obj,
                request.user,
                "CONSULTATION_CONTENU",
                "Consultation de la fiche détaillée.",
            )

        if peut_voir_pieces:
            journaliser_acces_confidentiel(
                obj,
                request.user,
                "CONSULTATION_PIECE",
                "Accès à la liste des pièces jointes.",
            )

        if peut_voir_historique:
            journaliser_acces_confidentiel(
                obj,
                request.user,
                "CONSULTATION_HISTORIQUE",
                "Consultation de l'historique.",
            )

    peut_modifier = (
        profil != "ADMIN"
        and utilisateur_peut_modifier_courrier(
            request.user,
            obj,
        )
    )

    affectations = Affectation.objects.filter(
        courrier=obj,
    ).select_related(
        "service",
        "agent",
        "transmis_par",
        "confirme_par",
    ).order_by("-date_transmission")

    pieces_jointes = PieceJointe.objects.none()

    if peut_voir_pieces:

        pieces_jointes = PieceJointe.objects.filter(
            courrier=obj,
            active=True,
        ).select_related("ajoute_par")

    historique = Historique.objects.none()

    if peut_voir_historique:

        historique = Historique.objects.filter(
            courrier=obj,
        ).select_related(
            "utilisateur",
        ).order_by("-date_action")

    context = {
        "courrier": obj,
        "affectations": affectations,
        "pieces_jointes": pieces_jointes,
        "historique": historique,

        "retours": RetourCourrier.objects.filter(
            courrier=obj,
        ).select_related(
            "retourne_par",
            "nouveau_courrier",
        ).order_by("-date_retour"),

        "profil": profil,

        "peut_modifier": peut_modifier,
        "peut_voir_contenu": peut_voir_contenu,
        "peut_voir_pieces": peut_voir_pieces,
        "peut_voir_historique": peut_voir_historique,

        "peut_transmettre": utilisateur_peut_transmettre(
            request.user,
            obj,
        ),

        "peut_affecter_agent": utilisateur_peut_affecter_agent(
            request.user,
            obj,
        ),

        "peut_traiter": utilisateur_peut_traiter_courrier(
            request.user,
            obj,
        ),

        "peut_cloturer": utilisateur_peut_cloturer_courrier(
            request.user,
            obj,
        ),

        "peut_retourner": utilisateur_peut_retourner_courrier(
            request.user,
            obj,
        ),

        "peut_reouvrir": utilisateur_peut_reouvrir_courrier(
            request.user,
            obj,
        ),

        "peut_ajouter_piece_jointe": (
            peut_voir_pieces
            and (
                utilisateur_peut_modifier_courrier(
                    request.user,
                    obj,
                )
                or utilisateur_peut_traiter_courrier(
                    request.user,
                    obj,
                )
            )
        ),
    }

    return render(
        request,
        "courrier/detail.html",
        context,
    )


# ============================================================
# MODIFICATION D'UN COURRIER
# ============================================================

@login_required
def modifier_courrier(request, pk):

    obj = obtenir_courrier_accessible(
        request.user,
        pk,
    )

    profil = obtenir_profil(request.user)

    if not utilisateur_peut_modifier_courrier(
        request.user,
        obj,
    ):
        raise PermissionDenied(
            "Vous ne pouvez pas modifier ce courrier."
        )

    if request.method == "POST":

        form = CourrierForm(
            request.POST,
            request.FILES,
            instance=obj,
        )

        if form.is_valid():

            ancien_service = obj.service
            ancienne_reference = obj.reference

            with transaction.atomic():

                modification = form.save(commit=False)

                # Le formulaire de modification ne permet pas
                # de contourner le circuit de transmission.
                modification.sens = obj.sens
                modification.statut = obj.statut
                modification.date_cloture = obj.date_cloture
                modification.courrier_origine = obj.courrier_origine

                if profil != "ADMIN":
                    modification.service = ancien_service
                    modification.responsable = obj.responsable
                    modification.date_expedition = obj.date_expedition

                modification.save()
                form.save_m2m()

                enregistrer_pieces_jointes(
                    obj,
                    form.cleaned_data.get("documents", []),
                    request.user,
                )

                enregistrer_historique(
                    obj,
                    request.user,
                    "MODIFICATION",
                    details="Modification de la fiche courrier.",
                    avant=f"Référence : {ancienne_reference}",
                    apres=f"Objet : {obj.objet}",
                )

            messages.success(
                request,
                "Le courrier a été modifié.",
            )

            return redirect(
                "detail_courrier",
                pk=obj.pk,
            )

    else:

        form = CourrierForm(instance=obj)

    return render(
        request,
        "courrier/formulaire.html",
        {
            "form": form,
            "courrier": obj,
            "titre": "Modifier le courrier",
            "libelle_bouton": "Enregistrer les modifications",
        },
    )


# ============================================================
# TRANSMISSION À UN SERVICE
# ============================================================

@login_required
def transmettre_courrier(request, pk):

    obj = obtenir_courrier_accessible(
        request.user,
        pk,
    )

    if not utilisateur_peut_transmettre(
        request.user,
        obj,
    ):
        raise PermissionDenied(
            "Vous ne disposez pas du droit de transmettre ce courrier."
        )

    if (
        obj.sens != Courrier.Sens.ENTRANT
        or obj.statut != Courrier.Statut.ENREGISTRE
    ):
        raise PermissionDenied(
            "Seul un courrier entrant enregistré et non transmis "
            "peut être transmis."
        )

    if request.method == "POST":

        form = AffectationForm(request.POST)

        if form.is_valid():

            service = form.cleaned_data["service"]

            if not service.actif:

                form.add_error(
                    "service",
                    "Ce service n'est plus actif.",
                )

            if not form.errors:

                with transaction.atomic():

                    affectation = Affectation(
                        courrier=obj,
                        service=service,
                        agent=None,
                        transmis_par=request.user,
                        instruction=form.cleaned_data.get("instruction", ""),
                        date_limite=form.cleaned_data.get("date_limite"),
                        active=True,
                    )

                    affectation.save()

                    obj.service = service

                    # Le champ historique reste renseigné uniquement
                    # si le service possède un responsable historique.
                    obj.responsable = service.responsable

                    obj.statut = Courrier.Statut.TRANSMIS

                    obj.save(
                        update_fields=[
                            "service",
                            "responsable",
                            "statut",
                            "modifie_le",
                        ]
                    )

                    enregistrer_historique(
                        obj,
                        request.user,
                        "TRANSMISSION",
                        details=(
                            f"Courrier transmis au service {service.nom}."
                        ),
                    )

                messages.success(
                    request,
                    "Le courrier a été transmis au service sélectionné.",
                )

                return redirect(
                    "detail_courrier",
                    pk=obj.pk,
                )

    else:

        form = AffectationForm()

    return render(
        request,
        "courrier/formulaire.html",
        {
            "form": form,
            "courrier": obj,
            "titre": "Transmettre le courrier",
            "libelle_bouton": "Confirmer la transmission",
        },
    )


# ============================================================
# AFFECTATION À PLUSIEURS AGENTS
# ============================================================

@login_required
def affecter_agent(request, pk):

    obj = obtenir_courrier_accessible(
        request.user,
        pk,
    )

    if not utilisateur_peut_affecter_agent(
        request.user,
        obj,
    ):
        raise PermissionDenied(
            "Vous ne pouvez pas affecter ce courrier à un agent."
        )

    if not obj.service_id:
        raise PermissionDenied(
            "Ce courrier n'est rattaché à aucun service."
        )

    if request.method == "POST":

        form = AffectationForm(request.POST)

        if form.is_valid():

            service = form.cleaned_data["service"]
            agents = form.cleaned_data["agents"]

            if service.pk != obj.service_id:

                form.add_error(
                    "service",
                    "L'affectation doit rester dans le service destinataire.",
                )

            if not agents:

                form.add_error(
                    "agents",
                    "Veuillez sélectionner au moins un agent.",
                )

            if not form.errors:

                with transaction.atomic():

                    nouveaux_agents = []

                    for agent in agents:

                        deja_affecte = Affectation.objects.filter(
                            courrier=obj,
                            agent=agent,
                            type_affectation="AGENT",
                            active=True,
                        ).exists()

                        if deja_affecte:
                            continue

                        affectation = Affectation(
                            courrier=obj,
                            service=obj.service,
                            agent=agent,
                            type_affectation="AGENT",
                            transmis_par=request.user,
                            instruction=form.cleaned_data.get(
                                "instruction",
                                "",
                            ),
                            date_limite=form.cleaned_data.get(
                                "date_limite",
                            ),
                            active=True,
                        )

                        affectation.save()
                        nouveaux_agents.append(agent)

                        enregistrer_historique(
                            obj,
                            request.user,
                            "AFFECTATION_AGENT",
                            details=(
                                "Courrier affecté à "
                                f"{agent.get_full_name() or agent.username}."
                            ),
                        )

                    if not nouveaux_agents:
                        messages.info(
                            request,
                            "Tous les agents sélectionnés possèdent "
                            "déjà une affectation active.",
                        )
                    else:
                        messages.success(
                            request,
                            f"{len(nouveaux_agents)} agent(s) affecté(s) "
                            "au courrier.",
                        )

                return redirect(
                    "detail_courrier",
                    pk=obj.pk,
                )

    else:

        form = AffectationForm(
            initial={
                "service": obj.service_id,
            }
        )

    return render(
        request,
        "courrier/formulaire.html",
        {
            "form": form,
            "courrier": obj,
            "titre": "Affecter à un ou plusieurs agents",
            "libelle_bouton": "Confirmer les affectations",
        },
    )


# ============================================================
# TRAITEMENT D'UN COURRIER
# ============================================================

@login_required
def traiter_courrier(request, pk):

    obj = obtenir_courrier_accessible(
        request.user,
        pk,
    )

    if not utilisateur_peut_traiter_courrier(
        request.user,
        obj,
    ):
        raise PermissionDenied(
            "Vous ne pouvez pas traiter ce courrier."
        )

    profil = obtenir_profil(request.user)

    affectations = Affectation.objects.filter(
        courrier=obj,
        active=True,
    )

    if profil == "AGENT":

        affectations = affectations.filter(
            agent=request.user,
            type_affectation="AGENT",
        )

    elif profil == "RESPONSABLE":

        affectations = affectations.filter(
            service=obj.service,
        )

    if not affectations.exists():
        raise PermissionDenied(
            "Aucune affectation active ne vous permet de traiter ce courrier."
        )

    if request.method == "POST":

        form = TraitementForm(request.POST)

        if form.is_valid():

            nouveau_statut = form.cleaned_data["statut"]
            observation = form.cleaned_data["observation"]

            with transaction.atomic():

                for affectation in affectations.select_for_update():

                    affectation.statut = nouveau_statut
                    affectation.observation = observation

                    affectation.save(
                        update_fields=[
                            "statut",
                            "observation",
                        ]
                    )

                obj.statut = nouveau_statut

                obj.save(
                    update_fields=[
                        "statut",
                        "modifie_le",
                    ]
                )

                enregistrer_historique(
                    obj,
                    request.user,
                    "TRAITEMENT",
                    details=f"Statut : {nouveau_statut}",
                    motif=observation,
                )

            messages.success(
                request,
                "Le traitement du courrier a été enregistré.",
            )

            return redirect(
                "detail_courrier",
                pk=obj.pk,
            )

    else:

        form = TraitementForm(
            initial={
                "statut": (
                    obj.statut
                    if obj.statut in [
                        "EN_COURS",
                        "EN_ATTENTE",
                        "TRAITE",
                    ]
                    else "EN_COURS"
                )
            }
        )

    return render(
        request,
        "courrier/formulaire.html",
        {
            "form": form,
            "courrier": obj,
            "titre": "Traitement du courrier",
            "libelle_bouton": "Enregistrer le traitement",
        },
    )


# ============================================================
# RETOUR AU SECRÉTARIAT
# ============================================================

@login_required
def retourner_courrier(request, pk):

    obj = obtenir_courrier_accessible(
        request.user,
        pk,
    )

    if not utilisateur_peut_retourner_courrier(
        request.user,
        obj,
    ):
        raise PermissionDenied(
            "Vous ne pouvez pas retourner ce courrier."
        )

    if request.method == "POST":

        form = RetourForm(request.POST)

        if form.is_valid():

            motif = form.cleaned_data["motif"]

            with transaction.atomic():

                RetourCourrier.objects.create(
                    courrier=obj,
                    retourne_par=request.user,
                    motif=motif,
                )

                Affectation.objects.filter(
                    courrier=obj,
                    active=True,
                ).update(active=False)

                obj.service = None
                obj.responsable = None
                obj.statut = Courrier.Statut.ENREGISTRE

                obj.save(
                    update_fields=[
                        "service",
                        "responsable",
                        "statut",
                        "modifie_le",
                    ]
                )

                enregistrer_historique(
                    obj,
                    request.user,
                    "RETOUR_SECRETARIAT",
                    details="Courrier retourné au Secrétariat.",
                    motif=motif,
                )

            messages.success(
                request,
                "Le courrier a été retourné au Secrétariat.",
            )

            return redirect(
                "detail_courrier",
                pk=obj.pk,
            )

    else:

        form = RetourForm()

    return render(
        request,
        "courrier/formulaire.html",
        {
            "form": form,
            "courrier": obj,
            "titre": "Retourner le courrier",
            "libelle_bouton": "Confirmer le retour",
        },
    )


# ============================================================
# CLÔTURE
# ============================================================

@login_required
def cloturer_courrier(request, pk):

    obj = obtenir_courrier_accessible(
        request.user,
        pk,
    )

    if not utilisateur_peut_cloturer_courrier(
        request.user,
        obj,
    ):
        raise PermissionDenied(
            "Vous ne disposez pas du droit de clôturer ce courrier."
        )

    if obj.sens != Courrier.Sens.ENTRANT:
        raise PermissionDenied(
            "La clôture manuelle concerne uniquement les courriers entrants."
        )

    if obj.statut != Courrier.Statut.TRAITE:

        messages.warning(
            request,
            "Le courrier doit être marqué comme traité avant sa clôture.",
        )

        return redirect(
            "detail_courrier",
            pk=obj.pk,
        )

    if request.method == "POST":

        with transaction.atomic():

            obj.statut = Courrier.Statut.CLOTURE
            obj.date_cloture = timezone.localdate()

            obj.save(
                update_fields=[
                    "statut",
                    "date_cloture",
                    "modifie_le",
                ]
            )

            enregistrer_historique(
                obj,
                request.user,
                "CLOTURE",
                details="Clôture du courrier.",
            )

        messages.success(
            request,
            f"Le courrier {obj.reference} a été clôturé.",
        )

        return redirect(
            "detail_courrier",
            pk=obj.pk,
        )

    return render(
        request,
        "courrier/confirmation_cloture.html",
        {
            "courrier": obj,
            "titre": "Clôturer le courrier",
        },
    )


# ============================================================
# RÉOUVERTURE
# ============================================================

@login_required
def reouvrir_courrier(request, pk):

    obj = obtenir_courrier_accessible(
        request.user,
        pk,
    )

    if not utilisateur_peut_reouvrir_courrier(
        request.user,
        obj,
    ):
        raise PermissionDenied(
            "Vous ne pouvez pas rouvrir ce courrier."
        )

    if obj.statut != Courrier.Statut.CLOTURE:

        messages.warning(
            request,
            "Ce courrier n'est pas clôturé.",
        )

        return redirect(
            "detail_courrier",
            pk=obj.pk,
        )

    if request.method == "POST":

        form = MotifForm(request.POST)

        if form.is_valid():

            motif = form.cleaned_data["motif"]

            with transaction.atomic():

                obj.statut = (
                    Courrier.Statut.TRANSMIS
                    if obj.service_id
                    else Courrier.Statut.ENREGISTRE
                )

                obj.date_cloture = None

                obj.save(
                    update_fields=[
                        "statut",
                        "date_cloture",
                        "modifie_le",
                    ]
                )

                enregistrer_historique(
                    obj,
                    request.user,
                    "REOUVERTURE",
                    details="Réouverture du courrier.",
                    motif=motif,
                )

            messages.success(
                request,
                "Le courrier a été rouvert.",
            )

            return redirect(
                "detail_courrier",
                pk=obj.pk,
            )

    else:

        form = MotifForm()

    return render(
        request,
        "courrier/formulaire.html",
        {
            "form": form,
            "courrier": obj,
            "titre": "Réouvrir le courrier",
            "libelle_bouton": "Confirmer la réouverture",
        },
    )


# ============================================================
# AJOUT D'UNE PIÈCE JOINTE
# ============================================================

@login_required
def ajouter_piece_jointe(request, pk):

    obj = obtenir_courrier_accessible(
        request.user,
        pk,
    )

    profil = obtenir_profil(request.user)

    peut_ajouter = (
        utilisateur_peut_modifier_courrier(
            request.user,
            obj,
        )
        or utilisateur_peut_traiter_courrier(
            request.user,
            obj,
        )
    )

    if not peut_ajouter:
        raise PermissionDenied(
            "Vous ne pouvez pas ajouter de pièce jointe à ce courrier."
        )

    if not utilisateur_peut_voir_pieces(
        request.user,
        obj,
    ):
        raise PermissionDenied(
            "Vous ne disposez pas de l'autorisation de consulter "
            "les pièces jointes de ce courrier."
        )

    if request.method == "POST":

        form = PieceJointeForm(
            request.POST,
            request.FILES,
        )

        if form.is_valid():

            fichier = form.cleaned_data["fichier"]

            with transaction.atomic():

                enregistrer_pieces_jointes(
                    obj,
                    [fichier],
                    request.user,
                )

                enregistrer_historique(
                    obj,
                    request.user,
                    "AJOUT_PIECE_JOINTE",
                    details=f"Ajout du fichier : {fichier.name}",
                )

            messages.success(
                request,
                "La pièce jointe a été ajoutée.",
            )

            return redirect(
                "detail_courrier",
                pk=obj.pk,
            )

    else:

        form = PieceJointeForm()

    return render(
        request,
        "courrier/formulaire.html",
        {
            "form": form,
            "courrier": obj,
            "titre": "Ajouter une pièce jointe",
            "libelle_bouton": "Ajouter le fichier",
        },
    )


# ============================================================
# RETRAIT LOGIQUE D'UNE PIÈCE JOINTE
# ============================================================

@login_required
def retirer_piece_jointe(request, pk, piece_id):

    obj = obtenir_courrier_accessible(
        request.user,
        pk,
    )

    piece = get_object_or_404(
        PieceJointe,
        pk=piece_id,
        courrier=obj,
        active=True,
    )

    if not utilisateur_peut_modifier_courrier(
        request.user,
        obj,
    ):
        raise PermissionDenied(
            "Vous ne pouvez pas retirer cette pièce jointe."
        )

    if not utilisateur_peut_voir_pieces(
        request.user,
        obj,
    ):
        raise PermissionDenied(
            "Vous ne disposez pas de l'autorisation nécessaire."
        )

    if request.method != "POST":
        raise PermissionDenied(
            "Cette opération doit être effectuée par formulaire."
        )

    motif = request.POST.get(
        "motif",
        "Retrait de la pièce jointe.",
    )

    with transaction.atomic():

        piece.active = False
        piece.retire_par = request.user
        piece.retire_le = timezone.now()
        piece.motif_retrait = motif

        piece.save(
            update_fields=[
                "active",
                "retire_par",
                "retire_le",
                "motif_retrait",
            ]
        )

        enregistrer_historique(
            obj,
            request.user,
            "RETRAIT_PIECE_JOINTE",
            details=f"Retrait logique du fichier : {piece.nom_original}",
            motif=motif,
        )

    messages.success(
        request,
        "La pièce jointe a été retirée de la fiche. "
        "Le fichier n'a pas été supprimé physiquement.",
    )

    return redirect(
        "detail_courrier",
        pk=obj.pk,
    )


# ============================================================
# CONFIRMATION DE RÉCEPTION
# ============================================================

@login_required
def confirmer_reception(request, pk):

    if request.method != "POST":
        raise PermissionDenied(
            "La confirmation de réception doit être effectuée par formulaire."
        )

    obj = obtenir_courrier_accessible(
        request.user,
        pk,
    )

    if obtenir_profil(request.user) not in [
        "RESPONSABLE",
        "DIRECTION",
    ]:
        raise PermissionDenied(
            "Vous ne disposez pas du droit de confirmer la réception."
        )

    if (
        not obj.service_id
        or not utilisateur_est_responsable_du_service(
            request.user,
            obj.service,
        )
    ):
        raise PermissionDenied(
            "Vous n'êtes pas responsable du service destinataire."
        )

    with transaction.atomic():

        courrier = (
            Courrier.objects
            .select_for_update()
            .select_related("service")
            .get(pk=obj.pk)
        )

        if not utilisateur_est_responsable_du_service(
            request.user,
            courrier.service,
        ):
            raise PermissionDenied

        affectation = (
            Affectation.objects
            .select_for_update()
            .filter(
                courrier=courrier,
                service=courrier.service,
                agent__isnull=True,
                active=True,
            )
            .order_by("-date_transmission", "-pk")
            .first()
        )

        if not affectation:
            raise PermissionDenied(
                "Aucune transmission active ne permet "
                "de confirmer la réception."
            )

        if affectation.date_confirmation_reception:

            messages.info(
                request,
                "La réception de ce courrier a déjà été confirmée.",
            )

            return redirect(
                "detail_courrier",
                pk=courrier.pk,
            )

        affectation.date_confirmation_reception = timezone.now()
        affectation.confirme_par = request.user

        affectation.save(
            update_fields=[
                "date_confirmation_reception",
                "confirme_par",
            ]
        )

        enregistrer_historique(
            courrier,
            request.user,
            "CONFIRMATION_RECEPTION",
            details=(
                "Réception confirmée par le responsable du service "
                f"{courrier.service.nom}."
            ),
        )

    messages.success(
        request,
        "La réception du courrier a été confirmée.",
    )

    return redirect(
        "detail_courrier",
        pk=obj.pk,
    )

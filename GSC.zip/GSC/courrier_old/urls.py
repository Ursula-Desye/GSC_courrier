
from django.urls import path

from . import views
from . import bordereaux
from . import exports


urlpatterns = [

    # TABLEAU DE BORD ET CONSULTATION
    path(
        "dashboard/",
        views.dashboard,
        name="dashboard_interne"
    ),

    path(
        "",
        views.liste_courriers,
        name="liste_courriers"
    ),

    # ENREGISTREMENT
    path(
        "nouveau/",
        views.nouveau_courrier,
        name="nouveau_courrier"
    ),

    # EXPORTATIONS EXCEL ET PDF
    path(
        "exporter/excel/",
        exports.exporter_courriers_excel,
        name="exporter_courriers_excel"
    ),

    path(
        "exporter/pdf/",
        exports.exporter_courriers_pdf,
        name="exporter_courriers_pdf"
    ),

    # BORDEREAUX DE TRANSMISSION COLLECTIVE
    path(
        "bordereaux/",
        bordereaux.liste_bordereaux,
        name="liste_bordereaux"
    ),

    path(
        "bordereaux/nouveau/",
        bordereaux.creer_bordereau,
        name="creer_bordereau"
    ),

    path(
        "bordereaux/<int:pk>/",
        bordereaux.detail_bordereau,
        name="detail_bordereau"
    ),

    path(
        "bordereaux/<int:pk>/receptionner/",
        bordereaux.receptionner_bordereau,
        name="receptionner_bordereau"
    ),

    # DETAIL ET MODIFICATION
    path(
        "<int:pk>/",
        views.detail_courrier,
        name="detail_courrier"
    ),

    path(
        "<int:pk>/modifier/",
        views.modifier_courrier,
        name="modifier_courrier"
    ),

    # TRANSMISSION ET AFFECTATION
    path(
        "<int:pk>/transmettre/",
        views.transmettre_courrier,
        name="transmettre_courrier"
    ),

    path(
        "<int:pk>/affecter-agent/",
        views.affecter_agent,
        name="affecter_agent"
    ),

    # CONFIRMATION DE RECEPTION
    path(
        "<int:pk>/confirmer-reception/",
        views.confirmer_reception,
        name="confirmer_reception"
    ),

    # TRAITEMENT
    path(
        "<int:pk>/traiter/",
        views.traiter_courrier,
        name="traiter_courrier"
    ),

    # RETOUR AU SECRETARIAT
    path(
        "<int:pk>/retourner/",
        views.retourner_courrier,
        name="retourner_courrier"
    ),

    # CLOTURE ET REOUVERTURE
    path(
        "<int:pk>/cloturer/",
        views.cloturer_courrier,
        name="cloturer_courrier"
    ),

    path(
        "<int:pk>/reouvrir/",
        views.reouvrir_courrier,
        name="reouvrir_courrier"
    ),

    # PIECES JOINTES
    path(
        "<int:pk>/pieces-jointes/ajouter/",
        views.ajouter_piece_jointe,
        name="ajouter_piece_jointe"
    ),

    path(
        "<int:pk>/pieces-jointes/<int:piece_id>/retirer/",
        views.retirer_piece_jointe,
        name="retirer_piece_jointe"
    ),
]

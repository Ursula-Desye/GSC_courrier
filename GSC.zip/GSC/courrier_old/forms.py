from pathlib import Path

from django import forms
from django.contrib.auth import get_user_model
from django.db.models import Q
from django.utils import timezone

from .models import (
    Courrier,
    Affectation,
    Service,
    CategorieCourrier,
    ResponsableService,
)

from .permissions import (
    obtenir_profil,
    services_accessibles_du_responsable,
)
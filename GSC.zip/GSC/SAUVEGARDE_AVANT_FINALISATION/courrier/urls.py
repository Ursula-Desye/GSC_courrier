
from django.urls import path
from . import views

urlpatterns = [

    # TABLEAU DE BORD INTERNE
    path(
        "dashboard/",
        views.dashboard,
        name="dashboard_interne"
    ),

    # LISTE DES COURRIERS
    path(
        "",
        views.liste_courriers,
        name="liste_courriers"
    ),

    # ENREGISTREMENT
    path(
        "nouveau/",
        views.nouveau_courrier,
        name="nouveau_courrier"
    ),

    # DETAIL
    path(
        "<int:pk>/",
        views.detail_courrier,
        name="detail_courrier"
    ),

    # MODIFICATION
    path(
        "<int:pk>/modifier/",
        views.modifier_courrier,
        name="modifier_courrier"
    ),

    # TRANSMISSION
    path(
        "<int:pk>/transmettre/",
        views.transmettre_courrier,
        name="transmettre_courrier"
    ),

    # CLOTURE
    path(
        "<int:pk>/cloturer/",
        views.cloturer_courrier,
        name="cloturer_courrier"
    ),
]

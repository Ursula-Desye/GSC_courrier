
from django.conf import settings
from django.db import models
from django.utils import timezone


# =====================================================
# SERVICE
# =====================================================

class Service(models.Model):
    nom = models.CharField(
        max_length=120,
        unique=True,
        verbose_name="Nom du service"
    )

    description = models.TextField(
        blank=True,
        verbose_name="Description"
    )

    responsable = models.ForeignKey(
        settings.AUTH_USER_MODEL,
        on_delete=models.PROTECT,
        related_name="services_diriges",
        null=True,
        blank=True,
        verbose_name="Responsable du service"
    )

    actif = models.BooleanField(
        default=True,
        verbose_name="Service actif"
    )

    class Meta:
        ordering = ["nom"]
        verbose_name = "Service"
        verbose_name_plural = "Services"

    def __str__(self):
        return self.nom


# =====================================================
# COURRIER
# =====================================================

class Courrier(models.Model):

    class Sens(models.TextChoices):
        ENTRANT = "ENTRANT", "Entrant"
        SORTANT = "SORTANT", "Sortant"

    class Priorite(models.TextChoices):
        NORMALE = "NORMALE", "Normale"
        URGENTE = "URGENTE", "Urgente"
        CONFIDENTIELLE = "CONFIDENTIELLE", "Confidentielle"

    class Statut(models.TextChoices):
        ENREGISTRE = "ENREGISTRE", "Enregistré"
        TRANSMIS = "TRANSMIS", "Transmis"
        EN_COURS = "EN_COURS", "En cours"
        EN_ATTENTE = "EN_ATTENTE", "En attente"
        TRAITE = "TRAITE", "Traité"
        CLOTURE = "CLOTURE", "Clôturé"

    reference = models.CharField(
        max_length=30,
        unique=True,
        blank=True
    )

    sens = models.CharField(
        max_length=10,
        choices=Sens.choices
    )

    date_courrier = models.DateField(
        default=timezone.localdate
    )

    date_reception_expedition = models.DateField(
        default=timezone.localdate
    )

    expediteur = models.CharField(max_length=180)
    destinataire = models.CharField(max_length=180)
    objet = models.CharField(max_length=250)
    description = models.TextField(blank=True)

    service = models.ForeignKey(
        Service,
        on_delete=models.PROTECT,
        related_name="courriers",
        null=True,
        blank=True
    )

    responsable = models.ForeignKey(
        settings.AUTH_USER_MODEL,
        on_delete=models.PROTECT,
        related_name="courriers_responsables",
        null=True,
        blank=True
    )

    priorite = models.CharField(
        max_length=20,
        choices=Priorite.choices,
        default=Priorite.NORMALE
    )

    statut = models.CharField(
        max_length=20,
        choices=Statut.choices,
        default=Statut.ENREGISTRE
    )

    date_limite = models.DateField(
        null=True,
        blank=True
    )

    date_cloture = models.DateField(
        null=True,
        blank=True
    )

    document = models.FileField(
        upload_to="courriers/%Y/%m/",
        blank=True,
        null=True
    )

    cree_par = models.ForeignKey(
        settings.AUTH_USER_MODEL,
        on_delete=models.PROTECT,
        related_name="courriers_crees"
    )

    cree_le = models.DateTimeField(auto_now_add=True)
    modifie_le = models.DateTimeField(auto_now=True)

    class Meta:
        ordering = ["-cree_le"]
        verbose_name = "Courrier"
        verbose_name_plural = "Courriers"

        permissions = [
            (
                "transmettre_courrier",
                "Peut transmettre un courrier"
            ),
            (
                "cloturer_courrier",
                "Peut clôturer un courrier"
            ),
        ]

    def save(self, *args, **kwargs):

        if not self.reference:
            prefix = (
                "ENT"
                if self.sens == self.Sens.ENTRANT
                else "SOR"
            )

            year = timezone.localdate().year

            last = (
                Courrier.objects
                .filter(
                    reference__startswith=f"{prefix}-{year}-"
                )
                .order_by("-id")
                .first()
            )

            seq = (last.id + 1) if last else 1

            self.reference = (
                f"{prefix}-{year}-{seq:06d}"
            )

        super().save(*args, **kwargs)

    def __str__(self):
        return f"{self.reference} – {self.objet}"


# =====================================================
# AFFECTATION
# =====================================================

class Affectation(models.Model):

    courrier = models.ForeignKey(
        Courrier,
        on_delete=models.CASCADE,
        related_name="affectations"
    )

    service = models.ForeignKey(
        Service,
        on_delete=models.PROTECT
    )

    agent = models.ForeignKey(
        settings.AUTH_USER_MODEL,
        on_delete=models.PROTECT,
        null=True,
        blank=True
    )

    transmis_par = models.ForeignKey(
        settings.AUTH_USER_MODEL,
        on_delete=models.PROTECT,
        related_name="transmissions_effectuees"
    )

    date_transmission = models.DateTimeField(
        default=timezone.now
    )

    instruction = models.TextField(blank=True)

    date_limite = models.DateField(
        null=True,
        blank=True
    )

    statut = models.CharField(
        max_length=30,
        default="TRANSMIS"
    )

    observation = models.TextField(blank=True)

    class Meta:
        ordering = ["-date_transmission"]
        verbose_name = "Affectation"
        verbose_name_plural = "Affectations"

    def __str__(self):
        return f"{self.courrier.reference} - {self.service}"


# =====================================================
# HISTORIQUE
# =====================================================

class Historique(models.Model):

    courrier = models.ForeignKey(
        Courrier,
        on_delete=models.CASCADE,
        related_name="historique"
    )

    utilisateur = models.ForeignKey(
        settings.AUTH_USER_MODEL,
        on_delete=models.PROTECT
    )

    action = models.CharField(max_length=100)

    details = models.TextField(blank=True)

    date_action = models.DateTimeField(
        auto_now_add=True
    )

    class Meta:
        ordering = ["-date_action"]
        verbose_name = "Historique"
        verbose_name_plural = "Historiques"

    def __str__(self):
        return f"{self.action} - {self.courrier.reference}"

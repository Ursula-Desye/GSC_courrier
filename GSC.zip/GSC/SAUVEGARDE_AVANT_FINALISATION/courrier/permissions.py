
# =====================================================
# PERMISSIONS ET PROFILS GSC
# =====================================================


def obtenir_profil(user):

    if not user.is_authenticated:
        return None

    if user.is_superuser:
        return "ADMIN"

    groupes = set(
        user.groups.values_list("name", flat=True)
    )

    # Ordre de priorité des profils

    if "Secrétariat" in groupes:
        return "SECRETARIAT"

    if "Direction" in groupes:
        return "DIRECTION"

    if "Responsable de service" in groupes:
        return "RESPONSABLE"

    if "Agent" in groupes:
        return "AGENT"

    return None


# =====================================================
# VERIFICATION ADMINISTRATEUR
# =====================================================

def est_administrateur(user):

    return (
        user.is_authenticated
        and user.is_superuser
    )


# =====================================================
# DROIT DE CONSULTATION
# =====================================================

def utilisateur_peut_consulter(user):

    return (
        user.is_authenticated
        and (
            user.is_superuser
            or (
                obtenir_profil(user) is not None
                and user.has_perm("courrier.view_courrier")
            )
        )
    )


# =====================================================
# DROIT D'ENREGISTREMENT
# =====================================================

def utilisateur_peut_enregistrer(user):

    profil = obtenir_profil(user)

    return (
        profil == "ADMIN"
        or (
            profil == "SECRETARIAT"
            and user.has_perm("courrier.add_courrier")
        )
    )


# =====================================================
# DROIT DE MODIFICATION
# =====================================================

def utilisateur_peut_modifier(user):

    profil = obtenir_profil(user)

    return (
        profil == "ADMIN"
        or (
            profil in ["SECRETARIAT", "RESPONSABLE"]
            and user.has_perm("courrier.change_courrier")
        )
    )


# =====================================================
# DROIT DE TRANSMISSION
# =====================================================

def utilisateur_peut_transmettre(user):

    profil = obtenir_profil(user)

    return (
        profil == "ADMIN"
        or (
            profil in ["SECRETARIAT", "RESPONSABLE"]
            and user.has_perm("courrier.transmettre_courrier")
        )
    )


# =====================================================
# DROIT DE CLOTURE
# =====================================================

def utilisateur_peut_cloturer(user):

    profil = obtenir_profil(user)

    return (
        profil == "ADMIN"
        or (
            profil == "RESPONSABLE"
            and user.has_perm("courrier.cloturer_courrier")
        )
    )


# =====================================================
# DROITS SPECIFIQUES PAR PROFIL
# =====================================================

def utilisateur_est_direction(user):

    return obtenir_profil(user) == "DIRECTION"


def utilisateur_est_responsable(user):

    return obtenir_profil(user) == "RESPONSABLE"


def utilisateur_est_agent(user):

    return obtenir_profil(user) == "AGENT"


def utilisateur_est_secretariat(user):

    return obtenir_profil(user) == "SECRETARIAT"

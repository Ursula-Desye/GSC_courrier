
from django.core.paginator import Paginator
from django.contrib.auth.decorators import login_required
from django.contrib import messages
from django.core.exceptions import PermissionDenied
from django.db.models import Q
from django.shortcuts import render, redirect, get_object_or_404
from django.utils import timezone

from .models import Courrier, Affectation, Historique, Service
from .forms import CourrierForm, AffectationForm

from .permissions import (
    obtenir_profil,
    utilisateur_peut_consulter,
    utilisateur_peut_enregistrer,
    utilisateur_peut_modifier,
    utilisateur_peut_transmettre,
    utilisateur_peut_cloturer,
)


# =====================================================
# SERVICES DIRIGES PAR UN RESPONSABLE
# =====================================================

def services_du_responsable(user):
    return Service.objects.filter(responsable=user)


def identifiants_services_responsable(user):
    return services_du_responsable(user).values_list(
        "id",
        flat=True
    )


# =====================================================
# CONTROLE DES DROITS DE CONSULTATION
# =====================================================

def verifier_droit_consultation(user):

    if not utilisateur_peut_consulter(user):
        raise PermissionDenied(
            "Vous ne disposez pas du droit de consultation."
        )

    return obtenir_profil(user)


# =====================================================
# FILTRAGE DES COURRIERS SELON LE PROFIL
# =====================================================

def courriers_accessibles(user):

    profil = verifier_droit_consultation(user)

    qs = Courrier.objects.select_related(
        "service",
        "responsable",
        "cree_par"
    )

    # ADMINISTRATEUR, SECRETARIAT ET DIRECTION
    if profil in ["ADMIN", "SECRETARIAT", "DIRECTION"]:
        return qs

    # RESPONSABLE : COURRIERS DE SON SERVICE
    if profil == "RESPONSABLE":
        return qs.filter(
            service__responsable=user
        ).distinct()

    # AGENT : COURRIERS QUI LUI SONT AFFECTES
    if profil == "AGENT":
        return qs.filter(
            affectations__agent=user
        ).distinct()

    return qs.none()


# =====================================================
# CONTROLE DES DROITS DE MODIFICATION
# =====================================================

def verifier_droit_modification(user):

    if not utilisateur_peut_modifier(user):
        raise PermissionDenied(
            "Vous ne disposez pas du droit de modification."
        )

    return obtenir_profil(user)


# =====================================================
# CONTROLE DES DROITS DE TRANSMISSION
# =====================================================

def verifier_droit_transmission(user):

    if not utilisateur_peut_transmettre(user):
        raise PermissionDenied(
            "Vous ne disposez pas du droit de transmission."
        )

    return obtenir_profil(user)


# =====================================================
# TABLEAU DE BORD
# =====================================================

@login_required
def dashboard(request):

    qs = courriers_accessibles(request.user)

    context = {
        "total": qs.count(),

        "entrants": qs.filter(
            sens="ENTRANT"
        ).count(),

        "sortants": qs.filter(
            sens="SORTANT"
        ).count(),

        "en_cours": qs.filter(
            statut__in=[
                "TRANSMIS",
                "EN_COURS",
                "EN_ATTENTE"
            ]
        ).count(),

        "traites": qs.filter(
            statut__in=[
                "TRAITE",
                "CLOTURE"
            ]
        ).count(),

        "recents": qs.order_by(
            "-cree_le"
        )[:8],

        "en_retard": qs.filter(
            date_limite__lt=timezone.localdate()
        ).exclude(
            statut__in=[
                "TRAITE",
                "CLOTURE"
            ]
        ).count(),
    }

    return render(
        request,
        "courrier/dashboard.html",
        context
    )


# =====================================================
# LISTE DES COURRIERS
# =====================================================

@login_required
def liste_courriers(request):

    qs = courriers_accessibles(request.user)

    q = request.GET.get("q", "").strip()
    sens = request.GET.get("sens", "")
    statut = request.GET.get("statut", "")
    categorie = request.GET.get("categorie", "")

    # FILTRAGE SELON LA CARTE CLIQUEE

    if categorie == "entrants":

        qs = qs.filter(sens="ENTRANT")
        filtre_titre = "Courriers entrants"

    elif categorie == "sortants":

        qs = qs.filter(sens="SORTANT")
        filtre_titre = "Courriers sortants"

    elif categorie == "en_cours":

        qs = qs.filter(
            statut__in=[
                "TRANSMIS",
                "EN_COURS",
                "EN_ATTENTE"
            ]
        )

        filtre_titre = "Courriers en cours de traitement"

    elif categorie == "traites":

        qs = qs.filter(
            statut__in=["TRAITE", "CLOTURE"]
        )

        filtre_titre = "Courriers traités / clôturés"

    elif categorie == "en_retard":

        qs = qs.filter(
            date_limite__lt=timezone.localdate()
        ).exclude(
            statut__in=["TRAITE", "CLOTURE"]
        )

        filtre_titre = "Courriers en retard"

    else:

        filtre_titre = "Tous les courriers"

    # RECHERCHE TEXTUELLE

    if q:

        qs = qs.filter(
            Q(reference__icontains=q)
            | Q(objet__icontains=q)
            | Q(expediteur__icontains=q)
            | Q(destinataire__icontains=q)
        )

    # FILTRES COMPLEMENTAIRES

    if sens in ["ENTRANT", "SORTANT"]:
        qs = qs.filter(sens=sens)

    if statut:
        qs = qs.filter(statut=statut)

    # PAGINATION

    nombre_par_page = request.GET.get(
        "par_page",
        "10"
    )

    if nombre_par_page not in [
        "10",
        "25",
        "50",
        "100"
    ]:

        nombre_par_page = "10"

    paginator = Paginator(
        qs.order_by("-cree_le"),
        int(nombre_par_page)
    )

    page_number = request.GET.get("page")
    page_obj = paginator.get_page(page_number)

    # CONTEXTE

    context = {
        "courriers": page_obj,
        "page_obj": page_obj,
        "paginator": paginator,
        "nombre_par_page": nombre_par_page,
        "q": q,
        "sens": sens,
        "statut": statut,
        "categorie": categorie,
        "filtre_titre": filtre_titre,
    }

    return render(
        request,
        "courrier/liste.html",
        context
    )


# =====================================================
# ENREGISTREMENT D'UN NOUVEAU COURRIER
# SECRETARIAT ET ADMINISTRATEUR
# =====================================================

@login_required
def nouveau_courrier(request):

    if not utilisateur_peut_enregistrer(request.user):
        raise PermissionDenied(
            "Seul le Secrétariat ou l'administrateur peut enregistrer un courrier."
        )

    if request.method == "POST":

        form = CourrierForm(
            request.POST,
            request.FILES
        )

        if form.is_valid():

            obj = form.save(commit=False)
            obj.cree_par = request.user
            obj.save()

            Historique.objects.create(
                courrier=obj,
                utilisateur=request.user,
                action="ENREGISTREMENT",
                details="Création du courrier"
            )

            messages.success(
                request,
                f"Courrier {obj.reference} enregistré."
            )

            return redirect(
                "detail_courrier",
                pk=obj.pk
            )

    else:

        form = CourrierForm()

    return render(
        request,
        "courrier/formulaire.html",
        {
            "form": form,
            "titre": "Nouveau courrier"
        }
    )


# =====================================================
# DETAIL D'UN COURRIER
# =====================================================

@login_required
def detail_courrier(request, pk):

    obj = get_object_or_404(
        courriers_accessibles(request.user),
        pk=pk
    )

    return render(
        request,
        "courrier/detail.html",
        {
            "courrier": obj
        }
    )


# =====================================================
# MODIFICATION D'UN COURRIER
# SECRETARIAT, RESPONSABLE ET ADMINISTRATEUR
# =====================================================

@login_required
def modifier_courrier(request, pk):

    profil = verifier_droit_modification(
        request.user
    )

    obj = get_object_or_404(
        courriers_accessibles(request.user),
        pk=pk
    )

    if request.method == "POST":

        form = CourrierForm(
            request.POST,
            request.FILES,
            instance=obj
        )

        if form.is_valid():

            # LE RESPONSABLE NE PEUT PAS
            # DEPLACER LE COURRIER VERS UN AUTRE SERVICE

            if profil == "RESPONSABLE":

                service = form.cleaned_data.get("service")

                services_autorises = (
                    identifiants_services_responsable(
                        request.user
                    )
                )

                if (
                    service is None
                    or not services_autorises.filter(
                        pk=service.pk
                    ).exists()
                ):

                    form.add_error(
                        "service",
                        "Vous ne pouvez sélectionner que votre propre service."
                    )

                else:

                    form.save()

            else:

                form.save()

            if not form.errors:

                Historique.objects.create(
                    courrier=obj,
                    utilisateur=request.user,
                    action="MODIFICATION",
                    details="Modification de la fiche"
                )

                messages.success(
                    request,
                    "Courrier modifié."
                )

                return redirect(
                    "detail_courrier",
                    pk=obj.pk
                )

    else:

        form = CourrierForm(
            instance=obj
        )

    return render(
        request,
        "courrier/formulaire.html",
        {
            "form": form,
            "titre": "Modifier le courrier"
        }
    )


# =====================================================
# TRANSMISSION D'UN COURRIER
# SECRETARIAT, RESPONSABLE ET ADMINISTRATEUR
# =====================================================

@login_required
def transmettre_courrier(request, pk):

    profil = verifier_droit_transmission(
        request.user
    )

    obj = get_object_or_404(
        courriers_accessibles(request.user),
        pk=pk
    )

    if request.method == "POST":

        form = AffectationForm(request.POST)

        if form.is_valid():

            aff = form.save(commit=False)

            # LE RESPONSABLE NE PEUT TRANSMETTRE
            # QUE VERS SON PROPRE SERVICE

            if profil == "RESPONSABLE":

                services_autorises = (
                    identifiants_services_responsable(
                        request.user
                    )
                )

                if not services_autorises.filter(
                    pk=aff.service_id
                ).exists():

                    form.add_error(
                        "service",
                        "Vous ne pouvez transmettre qu'à votre propre service."
                    )

            if not form.errors:

                aff.courrier = obj
                aff.transmis_par = request.user
                aff.save()

                obj.statut = "TRANSMIS"
                obj.service = aff.service
                obj.responsable = aff.agent
                obj.save()

                Historique.objects.create(
                    courrier=obj,
                    utilisateur=request.user,
                    action="TRANSMISSION",
                    details=f"Transmis au service {aff.service}"
                )

                messages.success(
                    request,
                    "Courrier transmis."
                )

                return redirect(
                    "detail_courrier",
                    pk=obj.pk
                )

    else:

        form = AffectationForm()

    return render(
        request,
        "courrier/formulaire.html",
        {
            "form": form,
            "titre": "Transmettre le courrier"
        }
    )


# =====================================================
# CLOTURE D'UN COURRIER
# RESPONSABLE ET ADMINISTRATEUR
# =====================================================

@login_required
def cloturer_courrier(request, pk):

    if not utilisateur_peut_cloturer(request.user):
        raise PermissionDenied(
            "Vous ne disposez pas du droit de clôturer un courrier."
        )

    obj = get_object_or_404(
        courriers_accessibles(request.user),
        pk=pk
    )

    if request.method == "POST":

        if obj.statut == "CLOTURE":

            messages.warning(
                request,
                "Ce courrier est déjà clôturé."
            )

            return redirect(
                "detail_courrier",
                pk=obj.pk
            )

        obj.statut = "CLOTURE"
        obj.date_cloture = timezone.localdate()
        obj.save()

        Historique.objects.create(
            courrier=obj,
            utilisateur=request.user,
            action="CLOTURE",
            details="Clôture définitive du courrier."
        )

        messages.success(
            request,
            f"Le courrier {obj.reference} a été clôturé."
        )

        return redirect(
            "detail_courrier",
            pk=obj.pk
        )

    return render(
        request,
        "courrier/confirmation_cloture.html",
        {
            "courrier": obj,
            "titre": "Clôturer le courrier"
        }
    )


from django.contrib import admin
from .models import Courrier, Service, Affectation, Historique


# =====================================================
# PERSONNALISATION DE L'ADMINISTRATION GSC
# =====================================================

admin.site.site_header = "GSC - Gestion et Suivi du Courrier"
admin.site.site_title = "Administration GSC"
admin.site.index_title = "Tableau de gestion"


# =====================================================
# GESTION DES SERVICES
# =====================================================

@admin.register(Service)
class ServiceAdmin(admin.ModelAdmin):

    list_display = (
        "nom",
        "responsable",
        "description",
        "actif",
    )

    list_filter = (
        "actif",
    )

    search_fields = (
        "nom",
        "description",
        "responsable__username",
        "responsable__first_name",
        "responsable__last_name",
    )

    list_select_related = (
        "responsable",
    )

    ordering = (
        "nom",
    )

    list_per_page = 25


# =====================================================
# GESTION DES COURRIERS
# =====================================================

@admin.register(Courrier)
class CourrierAdmin(admin.ModelAdmin):

    list_display = (
        "reference",
        "sens",
        "date_reception_expedition",
        "expediteur",
        "destinataire",
        "objet",
        "service",
        "responsable",
        "statut",
        "priorite",
    )

    list_filter = (
        "sens",
        "statut",
        "priorite",
        "service",
        "date_reception_expedition",
    )

    search_fields = (
        "reference",
        "objet",
        "description",
        "expediteur",
        "destinataire",
    )

    readonly_fields = (
        "reference",
        "cree_par",
        "cree_le",
        "modifie_le",
    )

    date_hierarchy = "date_reception_expedition"

    list_per_page = 25

    list_select_related = (
        "service",
        "responsable",
        "cree_par",
    )

    ordering = (
        "-cree_le",
    )


# =====================================================
# SUIVI DES AFFECTATIONS ET TRANSMISSIONS
# =====================================================

@admin.register(Affectation)
class AffectationAdmin(admin.ModelAdmin):

    list_display = (
        "courrier",
        "service",
        "agent",
        "transmis_par",
        "date_transmission",
        "date_limite",
        "statut",
    )

    list_filter = (
        "service",
        "statut",
        "date_transmission",
    )

    search_fields = (
        "courrier__reference",
        "courrier__objet",
        "service__nom",
        "agent__username",
        "transmis_par__username",
    )

    readonly_fields = (
        "date_transmission",
        "transmis_par",
    )

    date_hierarchy = "date_transmission"

    list_per_page = 25

    list_select_related = (
        "courrier",
        "service",
        "agent",
        "transmis_par",
    )

    ordering = (
        "-date_transmission",
    )


# =====================================================
# HISTORIQUE DES OPERATIONS
# CONSULTATION UNIQUEMENT
# =====================================================

@admin.register(Historique)
class HistoriqueAdmin(admin.ModelAdmin):

    list_display = (
        "courrier",
        "utilisateur",
        "action",
        "date_action",
    )

    list_filter = (
        "action",
        "date_action",
    )

    search_fields = (
        "courrier__reference",
        "courrier__objet",
        "utilisateur__username",
        "action",
        "details",
    )

    readonly_fields = (
        "courrier",
        "utilisateur",
        "action",
        "details",
        "date_action",
    )

    date_hierarchy = "date_action"

    list_per_page = 50

    list_select_related = (
        "courrier",
        "utilisateur",
    )

    ordering = (
        "-date_action",
    )

    def has_add_permission(self, request):
        return False

    def has_delete_permission(self, request, obj=None):
        return False

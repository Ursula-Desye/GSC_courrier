
from django import forms
from django.contrib.auth import get_user_model

from .models import Courrier, Affectation, Service


User = get_user_model()


# =====================================================
# FORMULAIRE D'ENREGISTREMENT ET DE MODIFICATION
# =====================================================

class CourrierForm(forms.ModelForm):

    class Meta:
        model = Courrier

        fields = [
            "sens",
            "date_courrier",
            "date_reception_expedition",
            "expediteur",
            "destinataire",
            "objet",
            "description",
            "service",
            "responsable",
            "priorite",
            "date_limite",
            "document",
        ]

        labels = {
            "sens": "Type de courrier",
            "date_courrier": "Date du courrier",
            "date_reception_expedition": "Date de réception / expédition",
            "expediteur": "Expéditeur",
            "destinataire": "Destinataire",
            "objet": "Objet du courrier",
            "description": "Description / Observations",
            "service": "Service concerné",
            "responsable": "Responsable du traitement",
            "priorite": "Niveau de priorité",
            "date_limite": "Date limite de traitement",
            "document": "Pièce jointe (PDF)",
        }

        widgets = {
            "sens": forms.Select(attrs={
                "class": "form-select",
            }),

            "date_courrier": forms.DateInput(attrs={
                "type": "date",
                "class": "form-control",
            }),

            "date_reception_expedition": forms.DateInput(attrs={
                "type": "date",
                "class": "form-control",
            }),

            "expediteur": forms.TextInput(attrs={
                "class": "form-control",
                "placeholder": "Nom de l'expéditeur",
            }),

            "destinataire": forms.TextInput(attrs={
                "class": "form-control",
                "placeholder": "Nom du destinataire",
            }),

            "objet": forms.TextInput(attrs={
                "class": "form-control",
                "placeholder": "Objet du courrier",
            }),

            "description": forms.Textarea(attrs={
                "rows": 4,
                "class": "form-control",
                "placeholder": "Informations complémentaires...",
            }),

            "service": forms.Select(attrs={
                "class": "form-select",
            }),

            "responsable": forms.Select(attrs={
                "class": "form-select",
            }),

            "priorite": forms.Select(attrs={
                "class": "form-select",
            }),

            "date_limite": forms.DateInput(attrs={
                "type": "date",
                "class": "form-control",
            }),

            "document": forms.ClearableFileInput(attrs={
                "class": "form-control",
                "accept": ".pdf,application/pdf",
            }),
        }

    def __init__(self, *args, **kwargs):

        super().__init__(*args, **kwargs)

        # CHAMPS OBLIGATOIRES

        champs_obligatoires = [
            "sens",
            "date_courrier",
            "date_reception_expedition",
            "expediteur",
            "destinataire",
            "objet",
        ]

        for nom in champs_obligatoires:
            self.fields[nom].required = True

        # CHAMPS FACULTATIFS

        champs_facultatifs = [
            "description",
            "service",
            "responsable",
            "date_limite",
            "document",
        ]

        for nom in champs_facultatifs:
            self.fields[nom].required = False

        # SERVICES ACTIFS

        services = Service.objects.filter(
            actif=True
        ).order_by("nom")

        # Conserver le service existant lors d'une modification,
        # même s'il a été désactivé depuis.

        if self.instance and self.instance.pk and self.instance.service_id:
            services = Service.objects.filter(
                pk=self.instance.service_id
            ) | services

        self.fields["service"].queryset = services.distinct()

        # UTILISATEURS ACTIFS POUR LE RESPONSABLE

        utilisateurs = User.objects.filter(
            is_active=True
        ).order_by(
            "last_name",
            "first_name",
            "username"
        )

        # Conserver le responsable existant lors d'une modification.

        if (
            self.instance
            and self.instance.pk
            and self.instance.responsable_id
        ):

            utilisateurs = User.objects.filter(
                pk=self.instance.responsable_id
            ) | utilisateurs

        self.fields["responsable"].queryset = (
            utilisateurs.distinct()
        )

        self.fields["document"].help_text = (
            "Format PDF recommandé."
        )

    def clean_document(self):

        document = self.cleaned_data.get("document")

        if document and not document.name.lower().endswith(".pdf"):
            raise forms.ValidationError(
                "Seuls les fichiers PDF sont autorisés."
            )

        return document


# =====================================================
# FORMULAIRE DE TRANSMISSION / AFFECTATION
# =====================================================

class AffectationForm(forms.ModelForm):

    class Meta:
        model = Affectation

        fields = [
            "service",
            "agent",
            "instruction",
            "date_limite",
        ]

        labels = {
            "service": "Service destinataire",
            "agent": "Agent responsable",
            "instruction": "Instruction de traitement",
            "date_limite": "Date limite de traitement",
        }

        widgets = {
            "service": forms.Select(attrs={
                "class": "form-select",
            }),

            "agent": forms.Select(attrs={
                "class": "form-select",
            }),

            "instruction": forms.Textarea(attrs={
                "rows": 3,
                "class": "form-control",
                "placeholder": "Instructions à transmettre au service...",
            }),

            "date_limite": forms.DateInput(attrs={
                "type": "date",
                "class": "form-control",
            }),
        }

    def __init__(self, *args, **kwargs):

        super().__init__(*args, **kwargs)

        # CHAMPS FACULTATIFS

        self.fields["instruction"].required = False
        self.fields["date_limite"].required = False
        self.fields["agent"].required = False

        # SERVICES ACTIFS UNIQUEMENT

        self.fields["service"].queryset = (
            Service.objects.filter(
                actif=True
            ).order_by("nom")
        )

        # UTILISATEURS ACTIFS APPARTENANT AU GROUPE AGENT

        agents = User.objects.filter(
            is_active=True,
            groups__name="Agent"
        ).order_by(
            "last_name",
            "first_name",
            "username"
        ).distinct()

        # Conserver l'agent déjà affecté lors d'une modification.

        if self.instance and self.instance.pk and self.instance.agent_id:

            agents = User.objects.filter(
                pk=self.instance.agent_id
            ) | agents

        self.fields["agent"].queryset = agents.distinct()

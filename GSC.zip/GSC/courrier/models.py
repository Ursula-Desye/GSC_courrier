
from django.conf import settings
from django.db import models, transaction
from django.utils import timezone


# =====================================================
# STRUCTURES ORGANISATIONNELLES
# =====================================================

class Service(models.Model):

    class TypeStructure(models.TextChoices):
        DIRECTION = "DIRECTION", "Direction"
        DEPARTEMENT = "DEPARTEMENT", "Département"
        SERVICE = "SERVICE", "Service"
        UNITE = "UNITE", "Unité"
        DIVISION = "DIVISION", "Division"
        AUTRE = "AUTRE", "Autre"

    nom = models.CharField(
        max_length=120,
        unique=True,
        verbose_name="Nom de la structure"
    )

    description = models.TextField(
        blank=True,
        verbose_name="Description"
    )

    responsable = models.ForeignKey(
        settings.AUTH_USER_MODEL,
        on_delete=models.PROTECT,
        related_name="services_diriges",
        null=True,
        blank=True,
        verbose_name="Responsable principal"
    )

    type_structure = models.CharField(
        max_length=20,
        choices=TypeStructure.choices,
        default=TypeStructure.SERVICE,
        verbose_name="Type de structure"
    )

    parent = models.ForeignKey(
        "self",
        on_delete=models.PROTECT,
        related_name="structures_enfants",
        null=True,
        blank=True,
        verbose_name="Structure de rattachement"
    )

    responsables = models.ManyToManyField(
        settings.AUTH_USER_MODEL,
        through="ResponsableService",
        through_fields=("service", "utilisateur"),
        related_name="services_responsable_multi",
        blank=True,
        verbose_name="Responsables"
    )

    actif = models.BooleanField(
        default=True,
        verbose_name="Structure active"
    )

    class Meta:
        ordering = ["nom"]
        verbose_name = "Structure"
        verbose_name_plural = "Structures"

    def __str__(self):
        return self.nom


# =====================================================
# CHEFS DE DEPARTEMENT ET RESPONSABILITES
# =====================================================

class ResponsableService(models.Model):

    service = models.ForeignKey(
        Service,
        on_delete=models.PROTECT,
        related_name="responsables_configures"
    )

    utilisateur = models.ForeignKey(
        settings.AUTH_USER_MODEL,
        on_delete=models.PROTECT,
        related_name="responsabilites_services"
    )

    description_perimetre = models.TextField(
        blank=True,
        verbose_name="Description du périmètre"
    )

    toutes_categories = models.BooleanField(
        default=True,
        verbose_name="Toutes les catégories"
    )

    categories = models.ManyToManyField(
        "CategorieCourrier",
        blank=True,
        related_name="responsables_autorises"
    )

    chef_departement = models.BooleanField(
        default=False,
        verbose_name="Chef de département",
        help_text="Indique si cet utilisateur est chef du département concerné."
    )

    peut_affecter_agents = models.BooleanField(
        default=True,
        verbose_name="Peut affecter des agents"
    )

    peut_cloturer = models.BooleanField(
        default=True,
        verbose_name="Peut clôturer les courriers"
    )

    inclure_structures_enfants = models.BooleanField(
        default=False,
        verbose_name="Accès aux structures rattachées"
    )

    actif = models.BooleanField(
        default=True,
        verbose_name="Responsabilité active"
    )

    date_creation = models.DateTimeField(auto_now_add=True)

    class Meta:
        ordering = ["service__nom", "utilisateur__username"]
        constraints = [
            models.UniqueConstraint(
                fields=["service", "utilisateur"],
                name="unique_responsable_service"
            )
        ]
        verbose_name = "Responsabilité de structure"
        verbose_name_plural = "Chefs de département et responsables"

    def __str__(self):
        role = "Chef de département" if self.chef_departement else "Responsable"
        return f"{role} : {self.utilisateur} - {self.service}"


# =====================================================
# COMPTEUR DES REFERENCES
# =====================================================

class CompteurReference(models.Model):

    sens = models.CharField(max_length=10)
    annee = models.PositiveIntegerField()
    dernier_numero = models.PositiveIntegerField(default=0)

    class Meta:
        constraints = [
            models.UniqueConstraint(
                fields=["sens", "annee"],
                name="unique_compteur_sens_annee"
            )
        ]
        verbose_name = "Compteur de référence"
        verbose_name_plural = "Compteurs de références"

    def __str__(self):
        return f"{self.sens}-{self.annee}: {self.dernier_numero}"


# =====================================================
# CATEGORIES DE COURRIER
# =====================================================

class CategorieCourrier(models.Model):

    nom = models.CharField(
        max_length=100,
        unique=True,
        verbose_name="Nom de la catégorie"
    )

    description = models.TextField(blank=True)
    actif = models.BooleanField(default=True)

    class Meta:
        ordering = ["nom"]
        verbose_name = "Catégorie de courrier"
        verbose_name_plural = "Catégories de courriers"

    def __str__(self):
        return self.nom


# =====================================================
# COURRIER
# =====================================================

class Courrier(models.Model):

    class Sens(models.TextChoices):
        ENTRANT = "ENTRANT", "Entrant"
        SORTANT = "SORTANT", "Sortant"

    class Priorite(models.TextChoices):
        NORMALE = "NORMALE", "Normale"
        URGENTE = "URGENTE", "Urgente"
        TRES_URGENTE = "TRES_URGENTE", "Très urgente"
        CONFIDENTIELLE = "CONFIDENTIELLE", "Confidentielle (ancienne valeur)"

    class Confidentialite(models.TextChoices):
        NORMALE = "NORMALE", "Normale"
        CONFIDENTIELLE = "CONFIDENTIELLE", "Confidentielle"
        STRICTE = "STRICTE", "Strictement confidentielle"

    class Statut(models.TextChoices):
        ENREGISTRE = "ENREGISTRE", "Enregistré"
        TRANSMIS = "TRANSMIS", "Transmis"
        EN_COURS = "EN_COURS", "En cours"
        EN_ATTENTE = "EN_ATTENTE", "En attente"
        TRAITE = "TRAITE", "Traité"
        CLOTURE = "CLOTURE", "Clôturé"

    class ModeReception(models.TextChoices):
        PHYSIQUE = "PHYSIQUE", "Courrier physique"
        EMAIL = "EMAIL", "E-mail"
        COURSIER = "COURSIER", "Coursier"
        DEPOT = "DEPOT", "Dépôt direct"
        AUTRE = "AUTRE", "Autre"

    class StatutOrientation(models.TextChoices):
        NON_EVALUE = "NON_EVALUE", "Non évalué"
        A_VALIDER = "A_VALIDER", "À valider"
        AUTOMATIQUE = "AUTOMATIQUE", "Orienté automatiquement"
        VALIDEE = "VALIDEE", "Orientation validée"
        REFUSEE = "REFUSEE", "Orientation refusée"

    reference = models.CharField(
        max_length=30,
        unique=True,
        blank=True
    )

    sens = models.CharField(
        max_length=10,
        choices=Sens.choices
    )

    date_courrier = models.DateField(default=timezone.localdate)

    date_reception_expedition = models.DateField(
        default=timezone.localdate
    )

    mode_reception = models.CharField(
        max_length=20,
        choices=ModeReception.choices,
        blank=True
    )

    date_reception_physique = models.DateTimeField(
        null=True,
        blank=True
    )

    nom_livreur = models.CharField(max_length=180, blank=True)

    date_expedition = models.DateField(null=True, blank=True)

    expediteur = models.CharField(max_length=180)
    destinataire = models.CharField(max_length=180)
    objet = models.CharField(max_length=250)
    description = models.TextField(blank=True)

    categorie = models.ForeignKey(
        CategorieCourrier,
        on_delete=models.PROTECT,
        related_name="courriers",
        null=True,
        blank=True
    )

    service = models.ForeignKey(
        Service,
        on_delete=models.PROTECT,
        related_name="courriers",
        null=True,
        blank=True
    )

    responsable = models.ForeignKey(
        settings.AUTH_USER_MODEL,
        on_delete=models.PROTECT,
        related_name="courriers_responsables",
        null=True,
        blank=True
    )

    destinataire_confidentiel = models.ForeignKey(
        settings.AUTH_USER_MODEL,
        on_delete=models.PROTECT,
        related_name="courriers_strictement_destines",
        null=True,
        blank=True
    )

    priorite = models.CharField(
        max_length=20,
        choices=Priorite.choices,
        default=Priorite.NORMALE
    )

    confidentialite = models.CharField(
        max_length=20,
        choices=Confidentialite.choices,
        default=Confidentialite.NORMALE
    )

    statut = models.CharField(
        max_length=20,
        choices=Statut.choices,
        default=Statut.ENREGISTRE
    )

    orientation_statut = models.CharField(
        max_length=20,
        choices=StatutOrientation.choices,
        default=StatutOrientation.NON_EVALUE
    )

    orientation_confiance = models.DecimalField(
        max_digits=5,
        decimal_places=2,
        null=True,
        blank=True
    )

    orientation_motif = models.TextField(blank=True)

    orientation_service_propose = models.ForeignKey(
        Service,
        on_delete=models.PROTECT,
        related_name="orientations_proposees",
        null=True,
        blank=True
    )

    orientation_validee_par = models.ForeignKey(
        settings.AUTH_USER_MODEL,
        on_delete=models.PROTECT,
        related_name="orientations_validees",
        null=True,
        blank=True
    )

    orientation_date = models.DateTimeField(null=True, blank=True)

    orientation_automatique = models.BooleanField(default=False)

    date_limite = models.DateField(null=True, blank=True)

    date_cloture = models.DateField(null=True, blank=True)

    document = models.FileField(
        upload_to="courriers/%Y/%m/",
        blank=True,
        null=True
    )

    courrier_origine = models.ForeignKey(
        "self",
        on_delete=models.PROTECT,
        related_name="courriers_reponse",
        null=True,
        blank=True
    )

    cree_par = models.ForeignKey(
        settings.AUTH_USER_MODEL,
        on_delete=models.PROTECT,
        related_name="courriers_crees"
    )

    cree_le = models.DateTimeField(auto_now_add=True)
    modifie_le = models.DateTimeField(auto_now=True)

    class Meta:
        ordering = ["-cree_le"]
        verbose_name = "Courrier"
        verbose_name_plural = "Courriers"
        permissions = [
            ("transmettre_courrier", "Peut transmettre un courrier"),
            ("cloturer_courrier", "Peut clôturer un courrier"),
            ("traiter_courrier", "Peut traiter un courrier"),
            ("retourner_courrier", "Peut retourner un courrier"),
            ("reouvrir_courrier", "Peut rouvrir un courrier"),
            ("valider_orientation", "Peut valider une orientation"),
            ("consulter_confidentiel", "Peut consulter un courrier confidentiel"),
        ]

    def save(self, *args, **kwargs):

        if not self.reference:
            prefix = (
                "ENT"
                if self.sens == self.Sens.ENTRANT
                else "SOR"
            )

            annee = timezone.localdate().year

            with transaction.atomic():
                compteur, cree = (
                    CompteurReference.objects
                    .select_for_update()
                    .get_or_create(
                        sens=self.sens,
                        annee=annee,
                        defaults={"dernier_numero": 0}
                    )
                )

                if cree or compteur.dernier_numero == 0:
                    anciennes_references = (
                        Courrier.objects
                        .filter(reference__startswith=f"{prefix}-{annee}-")
                        .values_list("reference", flat=True)
                    )

                    maximum = 0
                    for ancienne in anciennes_references:
                        try:
                            numero = int(ancienne.rsplit("-", 1)[1])
                            maximum = max(maximum, numero)
                        except (ValueError, IndexError):
                            continue

                    compteur.dernier_numero = max(
                        compteur.dernier_numero,
                        maximum
                    )

                compteur.dernier_numero += 1
                compteur.save(update_fields=["dernier_numero"])

                self.reference = (
                    f"{prefix}-{annee}-"
                    f"{compteur.dernier_numero:06d}"
                )

                super().save(*args, **kwargs)
        else:
            super().save(*args, **kwargs)

    def est_strictement_confidentiel(self):
        return self.confidentialite == self.Confidentialite.STRICTE

    def __str__(self):
        return f"{self.reference} – {self.objet}"


# =====================================================
# AFFECTATIONS ET TRANSMISSIONS
# =====================================================

class Affectation(models.Model):

    class TypeAffectation(models.TextChoices):
        SERVICE = "SERVICE", "Transmission à la structure"
        AGENT = "AGENT", "Affectation à un agent"

    courrier = models.ForeignKey(
        Courrier,
        on_delete=models.PROTECT,
        related_name="affectations"
    )

    service = models.ForeignKey(
        Service,
        on_delete=models.PROTECT,
        related_name="affectations"
    )

    agent = models.ForeignKey(
        settings.AUTH_USER_MODEL,
        on_delete=models.PROTECT,
        null=True,
        blank=True,
        related_name="affectations_agent"
    )

    type_affectation = models.CharField(
        max_length=20,
        choices=TypeAffectation.choices,
        default=TypeAffectation.SERVICE
    )

    transmis_par = models.ForeignKey(
        settings.AUTH_USER_MODEL,
        on_delete=models.PROTECT,
        related_name="transmissions_effectuees"
    )

    date_transmission = models.DateTimeField(default=timezone.now)
    instruction = models.TextField(blank=True)
    date_limite = models.DateField(null=True, blank=True)
    statut = models.CharField(max_length=30, default="TRANSMIS")
    observation = models.TextField(blank=True)

    active = models.BooleanField(
        default=True,
        verbose_name="Affectation active"
    )

    date_confirmation_reception = models.DateTimeField(
        null=True,
        blank=True
    )

    confirme_par = models.ForeignKey(
        settings.AUTH_USER_MODEL,
        on_delete=models.PROTECT,
        related_name="affectations_confirmees",
        null=True,
        blank=True
    )

    class Meta:
        ordering = ["-date_transmission"]
        verbose_name = "Affectation"
        verbose_name_plural = "Affectations"

    def save(self, *args, **kwargs):
        if (
            self.agent_id
            and self.type_affectation == self.TypeAffectation.SERVICE
        ):
            self.type_affectation = self.TypeAffectation.AGENT

        super().save(*args, **kwargs)

    def __str__(self):
        if self.agent_id:
            return f"{self.courrier.reference} - {self.agent}"
        return f"{self.courrier.reference} - {self.service}"


# =====================================================
# DELEGATIONS DE TRANSMISSION
# =====================================================

class DelegationTransmission(models.Model):

    utilisateur = models.ForeignKey(
        settings.AUTH_USER_MODEL,
        on_delete=models.PROTECT,
        related_name="delegations_recues"
    )

    autorise_par = models.ForeignKey(
        settings.AUTH_USER_MODEL,
        on_delete=models.PROTECT,
        related_name="delegations_autorisees"
    )

    date_debut = models.DateTimeField()
    date_fin = models.DateTimeField()
    motif = models.TextField(blank=True)
    actif = models.BooleanField(default=True)
    cree_le = models.DateTimeField(auto_now_add=True)

    class Meta:
        ordering = ["-date_debut"]
        verbose_name = "Délégation de transmission"
        verbose_name_plural = "Délégations de transmission"

    def est_valide(self):
        maintenant = timezone.now()
        return (
            self.actif
            and self.date_debut <= maintenant
            and self.date_fin >= maintenant
        )

    def __str__(self):
        return f"Délégation de {self.utilisateur}"


# =====================================================
# RETOURS DE COURRIER
# =====================================================

class RetourCourrier(models.Model):

    courrier = models.ForeignKey(
        Courrier,
        on_delete=models.PROTECT,
        related_name="retours"
    )

    retourne_par = models.ForeignKey(
        settings.AUTH_USER_MODEL,
        on_delete=models.PROTECT,
        related_name="courriers_retournes"
    )

    motif = models.TextField()
    date_retour = models.DateTimeField(auto_now_add=True)

    nouveau_courrier = models.ForeignKey(
        Courrier,
        on_delete=models.PROTECT,
        related_name="origine_retour",
        null=True,
        blank=True
    )

    traite = models.BooleanField(default=False)

    class Meta:
        ordering = ["-date_retour"]
        verbose_name = "Retour de courrier"
        verbose_name_plural = "Retours de courriers"

    def __str__(self):
        return f"Retour {self.courrier.reference}"


# =====================================================
# PIECES JOINTES
# =====================================================

class PieceJointe(models.Model):

    courrier = models.ForeignKey(
        Courrier,
        on_delete=models.PROTECT,
        related_name="pieces_jointes"
    )

    fichier = models.FileField(
        upload_to="courriers/pieces_jointes/%Y/%m/"
    )

    nom_original = models.CharField(max_length=255)
    type_mime = models.CharField(max_length=120, blank=True)
    taille = models.PositiveBigIntegerField(default=0)
    version = models.PositiveIntegerField(default=1)

    version_precedente = models.ForeignKey(
        "self",
        on_delete=models.PROTECT,
        related_name="versions_suivantes",
        null=True,
        blank=True
    )

    ajoute_par = models.ForeignKey(
        settings.AUTH_USER_MODEL,
        on_delete=models.PROTECT,
        related_name="pieces_jointes_ajoutees"
    )

    ajoute_le = models.DateTimeField(auto_now_add=True)
    active = models.BooleanField(default=True)
    motif_retrait = models.TextField(blank=True)

    retire_par = models.ForeignKey(
        settings.AUTH_USER_MODEL,
        on_delete=models.PROTECT,
        related_name="pieces_jointes_retirees",
        null=True,
        blank=True
    )

    retire_le = models.DateTimeField(null=True, blank=True)

    class Meta:
        ordering = ["-ajoute_le"]
        verbose_name = "Pièce jointe"
        verbose_name_plural = "Pièces jointes"

    def __str__(self):
        return f"{self.nom_original} - {self.courrier.reference}"


# =====================================================
# BORDEREAUX DE TRANSMISSION
# =====================================================

class BordereauTransmission(models.Model):

    service = models.ForeignKey(
        Service,
        on_delete=models.PROTECT,
        related_name="bordereaux"
    )

    date_transmission = models.DateTimeField(default=timezone.now)

    transmis_par = models.ForeignKey(
        settings.AUTH_USER_MODEL,
        on_delete=models.PROTECT,
        related_name="bordereaux_transmis"
    )

    statut = models.CharField(
        max_length=20,
        choices=[
            ("TRANSMIS", "Transmis"),
            ("RECEPTIONNE", "Réceptionné"),
        ],
        default="TRANSMIS"
    )

    class Meta:
        ordering = ["-date_transmission"]
        verbose_name = "Bordereau de transmission"
        verbose_name_plural = "Bordereaux de transmission"

    def __str__(self):
        return f"Bordereau {self.pk} - {self.service}"


class LigneBordereau(models.Model):

    bordereau = models.ForeignKey(
        BordereauTransmission,
        on_delete=models.PROTECT,
        related_name="lignes"
    )

    courrier = models.ForeignKey(
        Courrier,
        on_delete=models.PROTECT,
        related_name="lignes_bordereaux"
    )

    class Meta:
        constraints = [
            models.UniqueConstraint(
                fields=["bordereau", "courrier"],
                name="unique_courrier_bordereau"
            )
        ]
        verbose_name = "Ligne de bordereau"
        verbose_name_plural = "Lignes de bordereaux"

    def __str__(self):
        return f"{self.courrier.reference}"


class ReceptionBordereau(models.Model):

    bordereau = models.OneToOneField(
        BordereauTransmission,
        on_delete=models.PROTECT,
        related_name="reception"
    )

    service = models.ForeignKey(Service, on_delete=models.PROTECT)
    receptionne_par = models.ForeignKey(
        settings.AUTH_USER_MODEL,
        on_delete=models.PROTECT
    )

    date_reception = models.DateTimeField(auto_now_add=True)
    observation = models.TextField(blank=True)

    class Meta:
        verbose_name = "Réception de bordereau"
        verbose_name_plural = "Réceptions de bordereaux"

    def __str__(self):
        return f"Réception bordereau {self.bordereau_id}"


# =====================================================
# HISTORIQUE
# =====================================================

class Historique(models.Model):

    courrier = models.ForeignKey(
        Courrier,
        on_delete=models.PROTECT,
        related_name="historique"
    )

    utilisateur = models.ForeignKey(
        settings.AUTH_USER_MODEL,
        on_delete=models.PROTECT
    )

    action = models.CharField(max_length=100)
    details = models.TextField(blank=True)
    avant = models.TextField(blank=True)
    apres = models.TextField(blank=True)
    motif = models.TextField(blank=True)
    date_action = models.DateTimeField(auto_now_add=True)

    class Meta:
        ordering = ["-date_action"]
        verbose_name = "Historique"
        verbose_name_plural = "Historiques"

    def __str__(self):
        return f"{self.action} - {self.courrier.reference}"


# =====================================================
# AUTORISATIONS CONFIDENTIALITE
# =====================================================

class AutorisationConfidentialite(models.Model):

    class TypeAcces(models.TextChoices):
        CONTENU = "CONTENU", "Consulter le contenu"
        PIECES_JOINTES = "PIECES_JOINTES", "Consulter les pièces jointes"
        HISTORIQUE = "HISTORIQUE", "Consulter l'historique"

    courrier = models.ForeignKey(
        Courrier,
        on_delete=models.PROTECT,
        related_name="autorisations_confidentialite"
    )

    utilisateur = models.ForeignKey(
        settings.AUTH_USER_MODEL,
        on_delete=models.PROTECT,
        related_name="autorisations_confidentialite"
    )

    type_acces = models.CharField(
        max_length=20,
        choices=TypeAcces.choices,
        default=TypeAcces.CONTENU
    )

    autorise_par = models.ForeignKey(
        settings.AUTH_USER_MODEL,
        on_delete=models.PROTECT,
        related_name="autorisations_confidentialite_accordees"
    )

    motif = models.TextField()
    date_debut = models.DateTimeField(default=timezone.now)
    date_fin = models.DateTimeField(null=True, blank=True)
    actif = models.BooleanField(default=True)

    revoque_par = models.ForeignKey(
        settings.AUTH_USER_MODEL,
        on_delete=models.PROTECT,
        related_name="autorisations_confidentialite_revoquees",
        null=True,
        blank=True
    )

    date_revocation = models.DateTimeField(null=True, blank=True)
    date_creation = models.DateTimeField(auto_now_add=True)

    class Meta:
        ordering = ["-date_creation"]
        verbose_name = "Autorisation confidentielle"
        verbose_name_plural = "Autorisations confidentielles"

    def est_valide(self):
        maintenant = timezone.now()
        return (
            self.actif
            and self.date_debut <= maintenant
            and (
                self.date_fin is None
                or self.date_fin >= maintenant
            )
            and self.date_revocation is None
        )

    def __str__(self):
        return (
            f"{self.utilisateur} - "
            f"{self.courrier.reference} - {self.type_acces}"
        )


# =====================================================
# REGLES D'ORIENTATION
# =====================================================

class RegleOrientation(models.Model):

    class ModeCorrespondance(models.TextChoices):
        AU_MOINS_UN = "AU_MOINS_UN", "Au moins un mot-clé"
        TOUS = "TOUS", "Tous les mots-clés"

    nom = models.CharField(max_length=150)

    categorie = models.ForeignKey(
        CategorieCourrier,
        on_delete=models.PROTECT,
        related_name="regles_orientation",
        null=True,
        blank=True
    )

    mots_cles = models.TextField(
        blank=True,
        help_text="Mots-clés séparés par des virgules"
    )

    mode_correspondance = models.CharField(
        max_length=20,
        choices=ModeCorrespondance.choices,
        default=ModeCorrespondance.AU_MOINS_UN
    )

    service_destination = models.ForeignKey(
        Service,
        on_delete=models.PROTECT,
        related_name="regles_orientation"
    )

    priorite_regle = models.PositiveIntegerField(default=10)

    seuil_confiance = models.DecimalField(
        max_digits=5,
        decimal_places=2,
        default=80.00
    )

    actif = models.BooleanField(default=True)
    description = models.TextField(blank=True)

    cree_par = models.ForeignKey(
        settings.AUTH_USER_MODEL,
        on_delete=models.PROTECT,
        related_name="regles_orientation_creees",
        null=True,
        blank=True
    )

    cree_le = models.DateTimeField(auto_now_add=True)

    class Meta:
        ordering = ["priorite_regle", "nom"]
        verbose_name = "Règle d'orientation"
        verbose_name_plural = "Règles d'orientation"

    def __str__(self):
        return self.nom


# =====================================================
# JOURNAL DES ACCES CONFIDENTIELS
# =====================================================

class JournalAccesConfidentiel(models.Model):

    class Action(models.TextChoices):
        CONSULTATION_CONTENU = (
            "CONSULTATION_CONTENU",
            "Consultation du contenu"
        )
        CONSULTATION_PIECE = (
            "CONSULTATION_PIECE",
            "Consultation d'une pièce jointe"
        )
        CONSULTATION_HISTORIQUE = (
            "CONSULTATION_HISTORIQUE",
            "Consultation de l'historique"
        )
        EXPORT = "EXPORT", "Export"

    courrier = models.ForeignKey(
        Courrier,
        on_delete=models.PROTECT,
        related_name="journal_acces_confidentiels"
    )

    utilisateur = models.ForeignKey(
        settings.AUTH_USER_MODEL,
        on_delete=models.PROTECT,
        related_name="journal_acces_confidentiels"
    )

    action = models.CharField(
        max_length=30,
        choices=Action.choices
    )

    motif = models.TextField(blank=True)
    date_action = models.DateTimeField(auto_now_add=True)

    class Meta:
        ordering = ["-date_action"]
        verbose_name = "Journal d'accès confidentiel"
        verbose_name_plural = "Journaux des accès confidentiels"

    def __str__(self):
        return (
            f"{self.utilisateur} - "
            f"{self.courrier.reference} - {self.action}"
        )


# =====================================================
# PARAMETRES GENERAUX GSC
# =====================================================

class ParametreGSC(models.Model):

    class AppellationUnite(models.TextChoices):
        SERVICE = "SERVICE", "Service"
        DEPARTEMENT = "DEPARTEMENT", "Département"
        DIRECTION = "DIRECTION", "Direction"
        STRUCTURE = "STRUCTURE", "Structure"
        DIVISION = "DIVISION", "Division"
        AUTRE = "AUTRE", "Autre"

    delai_defaut_jours = models.PositiveIntegerField(
        null=True,
        blank=True,
        default=None,
        verbose_name="Délai de traitement par défaut"
    )

    duree_conservation_annees = models.PositiveIntegerField(
        null=True,
        blank=True,
        default=None,
        verbose_name="Durée de conservation (années)"
    )

    alerte_retard_active = models.BooleanField(default=True)
    notification_email_active = models.BooleanField(default=True)

    seuil_orientation_automatique = models.DecimalField(
        max_digits=5,
        decimal_places=2,
        default=80.00,
        verbose_name="Seuil de confiance de l'orientation automatique"
    )

    appellation_unite = models.CharField(
        max_length=20,
        choices=AppellationUnite.choices,
        default=AppellationUnite.SERVICE,
        verbose_name="Appellation des unités organisationnelles"
    )

    appellation_unite_personnalisee = models.CharField(
        max_length=80,
        blank=True,
        default="",
        verbose_name="Appellation personnalisée",
        help_text="À renseigner uniquement lorsque Autre est sélectionné."
    )

    modifie_par = models.ForeignKey(
        settings.AUTH_USER_MODEL,
        on_delete=models.PROTECT,
        null=True,
        blank=True
    )

    modifie_le = models.DateTimeField(auto_now=True)

    class Meta:
        verbose_name = "Paramètre GSC"
        verbose_name_plural = "Paramètres GSC"

    def obtenir_appellation_unite(self):
        if self.appellation_unite == self.AppellationUnite.AUTRE:
            return (
                self.appellation_unite_personnalisee.strip()
                or "Structure"
            )
        return self.get_appellation_unite_display()

    def obtenir_appellation_unites(self):
        pluriels = {
            "SERVICE": "Services",
            "DEPARTEMENT": "Départements",
            "DIRECTION": "Directions",
            "STRUCTURE": "Structures",
            "DIVISION": "Divisions",
        }

        if self.appellation_unite == self.AppellationUnite.AUTRE:
            return self.obtenir_appellation_unite() + "s"

        return pluriels.get(self.appellation_unite, "Structures")

    def __str__(self):
        return "Paramètres généraux GSC"


# =====================================================
# PERSONNEL AUTORISE PAR SERVICE (liste deroulante Excel)
# =====================================================

class PersonnelService(models.Model):

    service = models.ForeignKey(
        Service,
        on_delete=models.PROTECT,
        related_name="personnel"
    )

    utilisateur = models.ForeignKey(
        settings.AUTH_USER_MODEL,
        on_delete=models.PROTECT,
        related_name="appartenances_service"
    )

    actif = models.BooleanField(default=True)

    class Meta:
        ordering = ["service__nom", "utilisateur__username"]
        constraints = [
            models.UniqueConstraint(
                fields=["service", "utilisateur"],
                name="unique_personnel_service"
            )
        ]
        verbose_name = "Personnel de service"
        verbose_name_plural = "Personnel des services"

    def __str__(self):
        return f"{self.utilisateur} - {self.service}"


# =====================================================
# SUIVI DU COURRIER (colonnes du fichier SUIVI_COURRIER.xlsx)
# =====================================================

class SuiviCourrier(models.Model):

    class Execution(models.TextChoices):
        OUI = "OUI", "Oui"
        NON = "NON", "Non"

    courrier = models.OneToOneField(
        Courrier,
        on_delete=models.PROTECT,
        related_name="suivi_excel"
    )

    ligne_source = models.PositiveIntegerField(
        null=True, blank=True, db_index=True,
        verbose_name="Ligne du fichier Excel"
    )

    numero_ordre = models.CharField(max_length=30, blank=True, verbose_name="N° d'ordre")
    nature = models.CharField(max_length=250, blank=True, verbose_name="Correspondance")
    reference_excel = models.CharField(max_length=250, blank=True, verbose_name="Référence")

    date_transmission_departement = models.DateField(null=True, blank=True)
    observation_retour_departement = models.TextField(blank=True)
    date_reception_departement = models.DateField(null=True, blank=True)

    responsable_nom = models.CharField(max_length=180, blank=True, verbose_name="Responsable du service")
    date_transmission_responsable = models.DateField(null=True, blank=True)
    observation_retour_responsable = models.TextField(blank=True)
    date_reception_responsable = models.DateField(null=True, blank=True)

    redacteur_nom = models.CharField(max_length=180, blank=True, verbose_name="Rédacteur")
    date_affectation_redacteur = models.DateField(null=True, blank=True)
    instructions_responsable = models.TextField(blank=True)

    redacteur_final_nom = models.CharField(max_length=180, blank=True, verbose_name="Réaffectation rédacteur final")
    date_affectation_redacteur_final = models.DateField(null=True, blank=True)
    date_reception_redacteur_final = models.DateField(null=True, blank=True)

    numero_dossier = models.CharField(max_length=60, blank=True, db_index=True, verbose_name="N° dossier")
    assure = models.CharField(max_length=250, blank=True, verbose_name="Assuré / Tiers")
    action_menee = models.TextField(blank=True, verbose_name="Action menée")
    date_traitement = models.DateField(null=True, blank=True)

    execution = models.CharField(
        max_length=3, choices=Execution.choices, blank=True,
        verbose_name="Exécution (OUI/NON)"
    )
    date_execution = models.DateField(null=True, blank=True)
    observations = models.TextField(blank=True)

    class Meta:
        ordering = ["-courrier__cree_le"]
        verbose_name = "Suivi du courrier"
        verbose_name_plural = "Suivis des courriers"

    def clean(self):
        from django.core.exceptions import ValidationError

        aujourdhui = timezone.localdate()
        erreurs = {}

        for champ in (
            "date_transmission_departement", "date_reception_departement",
            "date_transmission_responsable", "date_reception_responsable",
            "date_affectation_redacteur", "date_affectation_redacteur_final",
            "date_reception_redacteur_final", "date_traitement",
            "date_execution",
        ):
            valeur = getattr(self, champ)
            if valeur and valeur > aujourdhui:
                erreurs[champ] = "La date ne peut pas être dans le futur."

        if erreurs:
            raise ValidationError(erreurs)

    def __str__(self):
        return f"Suivi {self.courrier_id} - dossier {self.numero_dossier or '-'}"


# =====================================================
# DEMANDES D'ACCES TEMPORAIRE (remplacement entre agents)
# =====================================================

class DemandeAcces(models.Model):

    class Portee(models.TextChoices):
        AGENT = "AGENT", "Tous les dossiers en cours d'un collègue"
        COURRIERS = "COURRIERS", "Courriers précis"

    class Statut(models.TextChoices):
        EN_ATTENTE = "EN_ATTENTE", "En attente"
        ACCEPTEE = "ACCEPTEE", "Acceptée"
        REFUSEE = "REFUSEE", "Refusée"
        ANNULEE = "ANNULEE", "Annulée par le demandeur"
        REVOQUEE = "REVOQUEE", "Révoquée"

    demandeur = models.ForeignKey(
        settings.AUTH_USER_MODEL,
        on_delete=models.PROTECT,
        related_name="demandes_acces",
    )

    service = models.ForeignKey(
        Service,
        on_delete=models.PROTECT,
        related_name="demandes_acces",
    )

    agent_cible = models.ForeignKey(
        settings.AUTH_USER_MODEL,
        on_delete=models.PROTECT,
        related_name="demandes_acces_visant",
        verbose_name="Collègue remplacé",
    )

    portee = models.CharField(
        max_length=12,
        choices=Portee.choices,
        default=Portee.AGENT,
    )

    courriers = models.ManyToManyField(
        Courrier,
        blank=True,
        related_name="demandes_acces",
    )

    motif = models.TextField()
    jours_demandes = models.PositiveSmallIntegerField(default=7)

    statut = models.CharField(
        max_length=12,
        choices=Statut.choices,
        default=Statut.EN_ATTENTE,
    )

    decide_par = models.ForeignKey(
        settings.AUTH_USER_MODEL,
        on_delete=models.PROTECT,
        related_name="demandes_acces_decidees",
        null=True,
        blank=True,
    )

    date_decision = models.DateTimeField(null=True, blank=True)
    commentaire_decision = models.TextField(blank=True)
    date_debut = models.DateTimeField(null=True, blank=True)
    date_fin = models.DateTimeField(null=True, blank=True)
    date_creation = models.DateTimeField(auto_now_add=True)

    class Meta:
        ordering = ["-date_creation"]
        verbose_name = "Demande d'accès"
        verbose_name_plural = "Demandes d'accès"

    def est_valide(self):
        maintenant = timezone.now()
        return (
            self.statut == self.Statut.ACCEPTEE
            and self.date_debut is not None
            and self.date_fin is not None
            and self.date_debut <= maintenant <= self.date_fin
        )

    def est_expiree(self):
        return (
            self.statut == self.Statut.ACCEPTEE
            and self.date_fin is not None
            and self.date_fin < timezone.now()
        )

    def etat(self):
        if self.est_expiree():
            return "Expirée"
        return self.get_statut_display()

    def __str__(self):
        return f"Demande {self.pk} : {self.demandeur} -> {self.agent_cible}"
